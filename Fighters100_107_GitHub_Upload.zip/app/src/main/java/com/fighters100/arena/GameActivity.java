package com.fighters100.arena;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.view.View;
import android.net.Uri;
import java.io.ByteArrayInputStream;

public class GameActivity extends Activity {
    private WebView gameView;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(5894);
        gameView = new WebView(this);
        WebSettings s = gameView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        gameView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String path = u.getPath();
                if ("https".equals(u.getScheme()) && "appassets.androidplatform.net".equals(u.getHost()) && path != null && path.startsWith("/assets/") && !path.contains("..")) {
                    try {
                        String name=path.substring(8);
                        String mime=name.endsWith(".html")?"text/html":name.endsWith(".js")?"application/javascript":name.endsWith(".css")?"text/css":name.endsWith(".mp3")?"audio/mpeg":"text/plain";
                        return new WebResourceResponse(mime, name.endsWith(".mp3")?null:"UTF-8",getAssets().open(name));
                    } catch (Exception ignored) {}
                }
                return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",null,new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {return true;}
        });
        gameView.setBackgroundColor(0xff0a1026);
        setContentView(gameView);
        gameView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    @Override protected void onPause() {
        if(gameView!=null){gameView.evaluateJavascript("window.GameAudio&&GameAudio.lifecycle(false)",null);gameView.onPause();}
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if(gameView!=null){gameView.onResume();gameView.evaluateJavascript("window.GameAudio&&GameAudio.lifecycle(true)",null);}
    }
    @Override protected void onDestroy() {
        if(gameView!=null){gameView.destroy();gameView=null;}
        super.onDestroy();
    }
}
