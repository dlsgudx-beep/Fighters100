(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const KEY = 'fighters100_arena_save_v1';
  const TIERS = [
    {name:'일반',color:'#b9c5d8',start:0},
    {name:'희귀',color:'#73b9ff',start:28},
    {name:'초희귀',color:'#b691ff',start:49},
    {name:'초초희귀',color:'#f789d4',start:67},
    {name:'초초초희귀',color:'#ffab65',start:81},
    {name:'초초초초희귀',color:'#ffe180',start:92},
    {name:'영웅',color:'#74ffe4',start:100},
    {name:'초영웅',color:'#ff7cff',start:102}
  ];
  const TICKET_TYPES = [
    {id:'rare',every:5,name:'희귀 뽑기권',tiers:[1],icon:'🎫',label:'희귀',accent:'#68bbff'},
    {id:'special',every:10,name:'특별 뽑기권',tiers:[2,3],icon:'🎟️',label:'초희귀 · 초초희귀',accent:'#e19aff'},
    {id:'ultra',every:100,name:'최상급 뽑기권',tiers:[4],icon:'🌟',label:'초초초희귀',accent:'#ffc27d'}
  ];
  const PREFIX = ['초롱','불꽃','바람','번개','강철','그림자','별빛','황금','태양','무한'];
  const SUFFIX = ['여우','늑대','용','고양이','해적','로봇','토끼','기사','마법사','호랑이'];
  const ICONS = ['🦊','🐺','🐲','🐱','🏴‍☠️','🤖','🐰','🛡️','🧙','🐯'];
  const ROLES = ['돌격형','정밀형','광역형','속도형','투척형','방어형','기동형','근접형','마법형','강타형'];
  const ATTACK_TYPES = [
    {name:'근접 검격',icon:'🗡️',detail:'가까운 적을 넓게 베기',range:105,cd:.64},
    {name:'회오리',icon:'🌀',detail:'움직이는 소용돌이로 여러 번 공격',range:285,cd:1.7},
    {name:'갈고리',icon:'🪝',detail:'갈고리를 던져 적을 끌어오기',range:310,cd:1.15},
    {name:'부메랑',icon:'🪃',detail:'던진 뒤 돌아올 때 적에게 피해',range:340,cd:1.3},
    {name:'화염',icon:'🔥',detail:'세 갈래로 뻗는 짧은 불길',range:195,cd:.95},
    {name:'연쇄 번개',icon:'⚡',detail:'적에서 다른 적으로 번지는 번개',range:295,cd:1.45},
    {name:'충격파',icon:'💥',detail:'주변의 적을 한꺼번에 공격',range:136,cd:1.5},
    {name:'얼음창',icon:'❄️',detail:'적을 관통하고 느리게 만드는 얼음',range:340,cd:1.05},
    {name:'폭탄',icon:'💣',detail:'날아가서 주변까지 폭발하는 폭탄',range:285,cd:1.45},
    {name:'레이저',icon:'🔆',detail:'일직선의 모든 적을 관통하는 빛',range:480,cd:1.28}
  ];
  function attackType(i){
    if(i===99)return {name:'무한 튕기기 10연발',icon:'♾️',detail:'기존처럼 10발이 빠르게 쏟아지고 영원히 튕겨!'};
    if(i===100)return {name:'전장 전체 공격',icon:'🌌',detail:'공격할 때마다 거리와 장애물에 관계없이 모든 상대에게 50 피해!'};
    if(i===101)return {name:'삼각 독가스 분사',icon:'☣️',detail:'앞쪽으로 전장 면적 약 1/4의 삼각형 독가스! 범위 안의 적에게 100 피해.'};
    if(i===102)return {name:'전장 독폭탄',icon:'🧪',detail:'자신만 빼고 모든 캐릭터에게 독폭탄! 맞으면 쓰러질 때까지 1초마다 체력 221 감소.'};
    if(i===103)return {name:'왕복 회오리 충격파',icon:'🌀',detail:'전장 끝까지 회오리 충격파가 퍼졌다가 되돌아와. 왕복 각각 400 피해.'};
    if(i===104)return {name:'10방향 얼음 폭풍',icon:'❄️',detail:'36도 간격으로 사방에 얼음창 10발을 발사. 한 발당 2000 피해.'};
    if(i===105)return {name:'관통 반사 레이저',icon:'🔱',detail:'레이저 한 발이 적을 관통하며 경기장 벽에서 반사돼. 한 발당 2001 피해.'};
    if(i===106)return {name:'초전설 연속 반사 레이저',icon:'🌠',detail:'발사 시 가까운 적을 향해 직진해. 벽이나 장애물에 닿을 때만 반사되고, 다음 벽까지는 계속 일직선으로 날아가. 적을 관통하며 2400 피해.'};
    return ATTACK_TYPES[i%10];
  }
  const MAPS = [
    {name:'별빛 경기장',color:'#183951',floor:'#23516a',wall:'#788ca9',blocks:[{x:410,y:248,w:180,h:104},{x:170,y:146,w:105,h:72},{x:735,y:386,w:100,h:72}]},
    {name:'돌바람 협곡',color:'#424058',floor:'#57546e',wall:'#a08a92',blocks:[{x:450,y:155,w:100,h:120},{x:450,y:335,w:100,h:115},{x:165,y:320,w:115,h:70},{x:720,y:210,w:115,h:70}]},
    {name:'초록 미로',color:'#24514f',floor:'#326961',wall:'#91aa7c',blocks:[{x:305,y:165,w:100,h:85},{x:595,y:350,w:100,h:85},{x:300,y:355,w:100,h:78},{x:600,y:170,w:100,h:78}]}
  ];
  const PRACTICE_MODES = [
    {id:'crowd',icon:'🎯',title:'25명 표적 훈련장',detail:'체력 2,000 × 25명 · 공격 안 함 · 전원 처치 시 전체 부활',map:{name:'표적 훈련 광장',color:'#244968',floor:'#326888',wall:'#789cb3',blocks:[]}},
    {id:'giant',icon:'🗿',title:'거대 괴물 동굴',detail:'체력 100,000 · 공격 안 함 · 처치하면 다시 출현',map:{name:'거대 괴물 동굴',color:'#3c3556',floor:'#4c436b',wall:'#897baf',blocks:[{x:430,y:82,w:95,h:75},{x:430,y:440,w:95,h:75}]}},
    {id:'duel',icon:'👹',title:'몬스터 결투장',detail:'체력 5,000 · 공격력 10 · 쓰러져도 다시 부활',map:{name:'몬스터 결투장',color:'#5a3435',floor:'#744746',wall:'#ba7460',blocks:[{x:455,y:80,w:95,h:68},{x:455,y:452,w:95,h:68}]}}
  ];
  const tiersFor = i => TIERS.reduce((found,t,k) => i >= t.start ? k : found,0);
  const FIGHTERS = Array.from({length:100},(_,i) => {
    const tier = tiersFor(i), hue = (i*37+18)%360;
    return {id:i,name:`${PREFIX[Math.floor(i/10)]} ${SUFFIX[i%10]}`,icon:ICONS[i%10],role:ROLES[i%10],tier,
      hp:125+i*3+tier*18,atk:19+Math.floor(i*.7)+tier*3,speed:148+(i%5)*9,range:260+(i%4)*28,
      bg:`linear-gradient(145deg,hsl(${hue},62%,45%),hsl(${(hue+55)%360},58%,26%))`,outline:TIERS[tier].color};
  });
  FIGHTERS[99].name='무한의 제왕';
  FIGHTERS.push({id:100,name:'히든 영웅',icon:'👑',role:'전장 지배형',tier:6,
    hp:825,atk:50,speed:185,range:1200,
    bg:'linear-gradient(145deg,#3be9c6,#25408e 55%,#7d40c0)',outline:TIERS[6].color});
  FIGHTERS.push({id:101,name:'독가스 군주',icon:'☣️',role:'독가스 범위형',tier:6,
    hp:1000,atk:100,speed:180,range:550,
    bg:'linear-gradient(145deg,#7bef62,#17633a 55%,#173d33)',outline:TIERS[6].color});
  FIGHTERS.push({id:102,name:'레전드 독가스 군주',icon:'🧪',role:'전장 독폭탄형',tier:7,
    hp:2000,atk:221,speed:175,range:1200,
    bg:'linear-gradient(145deg,#ee71ff,#64219d 52%,#1c164a)',outline:TIERS[7].color});
  FIGHTERS.push({id:103,name:'회오리 충격파 군주',icon:'🌀',role:'왕복 충격파형',tier:7,
    hp:3800,atk:400,speed:178,range:1350,
    bg:'linear-gradient(145deg,#42d9fa,#2c449c 55%,#7e27bf)',outline:TIERS[7].color});
  FIGHTERS.push({id:104,name:'얼음 폭풍 군주',icon:'❄️',role:'방사형 얼음창',tier:7,
    hp:4134,atk:2000,speed:171,range:750,
    bg:'linear-gradient(145deg,#baf5ff,#3d87be 55%,#233b89)',outline:TIERS[7].color});
  FIGHTERS.push({id:105,name:'야르란 군주',icon:'🔱',role:'관통 반사 레이저형',tier:7,
    hp:4000,atk:2001,speed:173,range:1200,
    bg:'linear-gradient(145deg,#ffcb7a,#b657cf 55%,#463b9b)',outline:TIERS[7].color});
  FIGHTERS.push({id:106,name:'슈퍼 레전드 엄청난 완료, 엄청난 최고, 엄청 엄청 엄청 엄청난 것 군주',icon:'🌠',role:'초전설 직선 반사 레이저형',tier:7,
    hp:4022,atk:2400,speed:180,range:1400,
    bg:'linear-gradient(145deg,#fff3a7,#e66aff 55%,#30207d)',outline:TIERS[7].color});
  const FINAL_FIGHTER_ID=106;
  const allBaseOwned=()=>Array.from({length:106},(_,i)=>i).every(i=>save.owned.includes(i));
  const baseOwnedCount=()=>Array.from({length:106},(_,i)=>i).filter(i=>save.owned.includes(i)).length;
  const ladderThreshold = i => i*(i+1)/2;
  const xpCost = i => 50*i*(tiersFor(i)+1);
  const defaultSave = () => ({wins:0,totalXp:0,matches:0,kos:0,owned:[0],selected:0,target:1,invested:{},fighterWins:{},tickets:{rare:0,special:0,ultra:0},coins:0});
  let save;
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    save = {...defaultSave(),...(raw && typeof raw === 'object' ? raw : {})};
    save.owned = Array.from(new Set([0,...(Array.isArray(save.owned)?save.owned:[]).filter(i=>Number.isInteger(i)&&i>=0&&i<FIGHTERS.length)]));
    // 107 is achievement-only: never trust a saved 107 without owning all 106 predecessors.
    if(allBaseOwned()){if(!save.owned.includes(FINAL_FIGHTER_ID))save.owned.push(FINAL_FIGHTER_ID);}
    else save.owned=save.owned.filter(i=>i!==FINAL_FIGHTER_ID);
    save.invested = save.invested && typeof save.invested==='object'?save.invested:{};
    // Each character keeps its own arena victories. Old saves start at level 1.
    save.fighterWins = save.fighterWins && typeof save.fighterWins==='object' && !Array.isArray(save.fighterWins)?save.fighterWins:{};
    // A save from before coins existed gets 200 coins for each existing victory once.
    const hasCoins=raw&&Object.prototype.hasOwnProperty.call(raw,'coins');
    save.coins=hasCoins?Math.max(0,Math.floor(Number(raw.coins)||0)):Math.max(0,Math.floor(Number(save.wins)||0))*200;
    // Save files from before tickets existed receive the tickets earned from previous wins.
    const oldTickets = raw && Object.prototype.hasOwnProperty.call(raw,'tickets') && raw.tickets && typeof raw.tickets==='object' ? raw.tickets : null;
    save.tickets = Object.fromEntries(TICKET_TYPES.map(t=>[t.id,oldTickets ? Math.max(0,Math.floor(Number(oldTickets[t.id])||0)) : Math.floor(Math.max(0,Number(save.wins)||0)/t.every)]));
    if (!save.owned.includes(save.selected)) save.selected=0;
    if (!Number.isInteger(save.target)||save.target<1||save.target>=FINAL_FIGHTER_ID) save.target=1;
    // Persist any new achievement awarded when loading a completed old save.
    try{localStorage.setItem(KEY,JSON.stringify(save));}catch{}
  } catch {save=defaultSave();}
  let mode='solo',filter='전체',inspected=0,game=null,raf=0;
  function persist(){try{localStorage.setItem(KEY,JSON.stringify(save));}catch{}}
  function tierStyle(i){const t=TIERS[tiersFor(i)];return `--fighter-bg:${FIGHTERS[i].bg};--fighter-border:${t.color};--tier-color:${t.color}`;}
  function portrait(i,cls='fighter-image'){const f=FIGHTERS[i];return `<div class="${cls}" style="${tierStyle(i)}">${f.icon}</div>`;}
  function chip(i){return `<span class="tier-chip" style="${tierStyle(i)}">${TIERS[tiersFor(i)].name}</span>`;}
  function pct(a,b){return Math.max(0,Math.min(100,b>0?a/b*100:100));}
  function progress(a,b,isGold=false){return `<div class="progress-track"><div class="progress-fill ${isGold?'gold':''}" style="width:${pct(a,b)}%"></div></div>`;}
  function fighterWinCount(i){return Math.max(0,Math.floor(Number(save.fighterWins[i])||0));}
  function fighterLevel(i){return Math.min(5,1+Math.floor(fighterWinCount(i)/3));}
  function fighterStats(i){const f=FIGHTERS[i],level=fighterLevel(i);
    return {level,hp:Math.round(f.hp*(1+.1*Math.min(level-1,3))),atk:Math.round(f.atk*(level===5?1.2:1))};
  }
  function levelInfo(i){const wins=fighterWinCount(i),level=fighterLevel(i);
    return `<span class="level-badge">⭐ Lv.${level}/5</span> <small>${level===5?'✨ 최대 레벨 · 특수 공격':`다음 레벨까지 ${3-wins%3}승`}</small>`;
  }
  function nextUnowned(){return FIGHTERS.find(f=>f.id>0 && f.id<FINAL_FIGHTER_ID && !save.owned.includes(f.id))?.id??null;}
  function ownedCount(){return save.owned.length;}
  function renderStats(){ $('winsCount').textContent=Number(save.wins).toLocaleString('ko-KR');$('xpCount').textContent=Number(save.totalXp).toLocaleString('ko-KR');$('coinsCount').textContent=Number(save.coins).toLocaleString('ko-KR');$('unlockedCount').textContent=`${ownedCount()} / ${FIGHTERS.length}`; }
  function renderCurrent(){const f=FIGHTERS[save.selected],s=fighterStats(f.id),a=attackType(f.id);$('activeFighter').innerHTML=`${portrait(f.id)}<div class="current-info"><span class="fighter-number">NO. ${String(f.id+1).padStart(3,'0')}</span><h3>${f.name}</h3>${chip(f.id)}<p>❤️ 체력 ${s.hp} &nbsp; ⚔ 공격 ${s.atk}</p><p>💚 3초마다 체력 +${f.tier>=6?100:40}</p><p>${a.icon} ${a.name}</p><p class="level-progress">${levelInfo(f.id)}</p></div>`;}
  function renderLadder(){const i=nextUnowned();if(i===null){$('ladderProgress').innerHTML=save.owned.includes(FINAL_FIGHTER_ID)?'<div class="next-reward">🏆 107종 모두 수집 완료!</div>':`<div class="next-reward">🔒 107번은 1~106번 전부 보유해야 해금! (${baseOwnedCount()}/106)</div>`;return;}
    const f=FIGHTERS[i],needed=ladderThreshold(i),prev=ladderThreshold(i-1),part=Math.max(0,save.wins-prev),total=needed-prev;
    $('ladderProgress').innerHTML=`<div class="next-reward">${portrait(i,'mini-portrait')}<div><small>다음 자동 보상 · ${i+1}번</small><b>${f.name}</b>${chip(i)}</div></div><div class="progress-heading"><strong>승리 ${Math.max(0,needed-save.wins)}번 더!</strong><span>${part} / ${total} 승</span></div>${progress(part,total,true)}`;
  }
  function renderTarget(){let i=save.target;if(save.owned.includes(i)){i=nextUnowned();if(i!==null)save.target=i;}
    if(i===null){$('targetProgress').innerHTML=save.owned.includes(FINAL_FIGHTER_ID)?'🏆 107종 모두 획득했어!':'🎁 106종 모두 보유하면 107번을 자동으로 얻어!';return;}
    const f=FIGHTERS[i],v=Math.max(0,Number(save.invested[i]||0)),cost=xpCost(i);
    $('targetProgress').innerHTML=`<div class="next-reward">${portrait(i,'mini-portrait')}<div><small>XP를 모으는 중 · ${i+1}번</small><b>${f.name}</b>${chip(i)}</div></div><div class="progress-heading"><strong>⚡ ${v.toLocaleString()} / ${cost.toLocaleString()} XP</strong><span>${Math.ceil(Math.max(0,cost-v)/50)}승 남음</span></div>${progress(v,cost)}<button class="small-action" id="chooseTarget">다른 캐릭터 선택하기 →</button>`;
    $('chooseTarget').addEventListener('click',()=>{$('rosterSection').scrollIntoView({behavior:'smooth'});});
  }
  function renderFilters(){const names=['전체',...TIERS.map(t=>t.name),'보유'];$('filterBar').innerHTML=names.map(n=>`<button class="filter-btn ${filter===n?'active':''}" data-filter="${n}">${n}</button>`).join('');}
  function eligibleForTicket(t){return FIGHTERS.filter(f=>f.id!==FINAL_FIGHTER_ID&&t.tiers.includes(f.tier)&&!save.owned.includes(f.id));}
  function renderGacha(){
    $('gachaCards').innerHTML=TICKET_TYPES.map(t=>{
      const count=save.tickets[t.id]||0,remaining=eligibleForTicket(t).length,within=save.wins%t.every;
      return `<article class="gacha-card" style="--ticket-accent:${t.accent}"><div class="ticket-top"><span class="ticket-icon">${t.icon}</span><span class="ticket-count">보유 <b>${count}</b>장</span></div><div class="ticket-milestone">${t.every}승마다 1장</div><h3>${t.name}</h3><div class="ticket-prize">${t.label} 캐릭터 중 랜덤 1명</div><div class="gacha-progress-label"><span>다음 이용권까지</span><strong>${within} / ${t.every}승</strong></div>${progress(within,t.every)}<button class="ticket-draw" data-roll="${t.id}" ${count===0||remaining===0?'disabled':''}>${remaining===0?'해당 등급 수집 완료':count>0?'🎲 이용권으로 뽑기':'🔒 이용권 모으기'}</button></article>`;
    }).join('');
  }
  function rollTicket(id){const t=TICKET_TYPES.find(t=>t.id===id);if(!t||save.tickets[id]<1)return;
    const candidates=eligibleForTicket(t);if(!candidates.length)return;
    const f=candidates[Math.floor(Math.random()*candidates.length)];save.tickets[id]--;
    const awards=[];unlock(f.id,awards);
    if(save.target===f.id){const next=nextUnowned();if(next!==null)save.target=next;}
    persist();renderAll();
    $('modalContent').innerHTML=`<div class="gacha-reveal">✨ 축하해! ✨</div>${portrait(f.id,'mini-portrait modal-portrait gacha-win-portrait')}<span class="fighter-number">뽑기 결과 · NO. ${String(f.id+1).padStart(3,'0')}</span><h2 id="fighterModalTitle">${f.name}</h2>${chip(f.id)}<p>🎉 ${t.name}으로 새로운 파이터를 얻었어!</p>${awards.includes(FINAL_FIGHTER_ID)?'<p class="final-unlock">🏆 1~106번 수집 완료! 107번 자동 해금!</p>':''}<div class="stat-grid"><div class="stat-cell"><b>${f.hp}</b><small>❤️ 체력</small></div><div class="stat-cell"><b>${f.atk}</b><small>⚔ 공격력</small></div><div class="stat-cell"><b>${f.speed}</b><small>💨 이동속도</small></div></div><div class="modal-actions"><button class="primary-button" id="equipDrawn">획득한 파이터로 출전!</button><button class="secondary-button" id="doneDraw">뽑기 화면으로 돌아가기</button></div>`;
    $('fighterModal').classList.remove('hidden');
    $('equipDrawn').onclick=()=>{save.selected=f.id;persist();renderAll();$('fighterModal').classList.add('hidden');};
    $('doneDraw').onclick=()=>{$('fighterModal').classList.add('hidden');};
  }
  function renderRoster(){const list=FIGHTERS.filter(f=>filter==='전체'||(filter==='보유'?save.owned.includes(f.id):TIERS[f.tier].name===filter));$('rosterGrid').innerHTML=list.map(f=>{
    const owned=save.owned.includes(f.id),chosen=f.id===save.selected;
    return `<button class="fighter-card ${owned?'':'is-locked'} ${chosen?'selected':''} ${f.id===FINAL_FIGHTER_ID?'final-fighter-card':''}" data-fighter="${f.id}" aria-label="${f.name}, ${TIERS[f.tier].name}, ${owned?'획득함':'잠김'}">${portrait(f.id)}${!owned?'<span class="lock-scrim">🔒</span>':''}<span class="card-num">NO. ${String(f.id+1).padStart(3,'0')} ${chosen?'✓':''}</span><span class="card-name">${f.name}</span>${chip(f.id)}<span class="card-attack">${attackType(f.id).icon} ${attackType(f.id).name}</span>${owned?`<span class="card-level">Lv.${fighterLevel(f.id)}</span>`:''}${f.id===FINAL_FIGHTER_ID&&!owned?'<span class="card-try">🔒 106종 수집 보상</span>':`<span class="card-try" data-try="${f.id}">▶ 체험하기</span>`}</button>`;
  }).join('');}
  const COIN_SHOP=[
    {price:2000,label:'초초초초희귀 이하 선택',maxTier:5,icon:'🥉'},
    {price:20000,label:'영웅 이하 선택',maxTier:6,icon:'🥈'},
    {price:200000,label:'1~106번 모든 캐릭터 선택',maxTier:7,icon:'🥇'}
  ];
  function renderCoinShop(){
    $('coinShopCards').innerHTML=COIN_SHOP.map((p,i)=>`<article class="coin-package"><div class="coin-package-icon">${p.icon}</div><h3>${p.label}</h3><p class="coin-price">🪙 ${p.price.toLocaleString('ko-KR')} 코인</p><small>원하는 캐릭터를 직접 선택해 구매</small><button class="coin-open" data-coin-package="${i}">캐릭터 선택 →</button></article>`).join('');
  }
  function openCoinPackage(index){
    const p=COIN_SHOP[index];if(!p)return;
    const choices=FIGHTERS.filter(f=>f.id!==FINAL_FIGHTER_ID&&f.tier<=p.maxTier&&!save.owned.includes(f.id));
    $('modalContent').innerHTML=`<div class="coin-shop-modal"><h2 id="fighterModalTitle">🪙 ${p.label}</h2><p>보유 코인: <b>${save.coins.toLocaleString('ko-KR')}</b> · 가격: <b>${p.price.toLocaleString('ko-KR')}</b></p><p class="coin-shop-note">${choices.length?'원하는 파이터를 골라 봐. 구매하면 코인이 차감돼.':'이 구간의 캐릭터를 모두 가지고 있어!'}</p><div class="coin-pick-grid">${choices.map(f=>`<button class="coin-pick" data-coin-fighter="${f.id}" ${save.coins<p.price?'disabled':''}>${f.icon} <b>${String(f.id+1).padStart(3,'0')} ${f.name}</b><small>${TIERS[f.tier].name}</small></button>`).join('')}</div></div>`;
    $('fighterModal').classList.remove('hidden');
    $('modalContent').querySelectorAll('[data-coin-fighter]').forEach(button=>button.addEventListener('click',()=>{
      const id=Number(button.dataset.coinFighter);
      if(!Number.isInteger(id)||id<0||id>=FINAL_FIGHTER_ID||FIGHTERS[id].tier>p.maxTier||save.owned.includes(id)||save.coins<p.price)return;
      save.coins-=p.price;const awards=[];unlock(id,awards);persist();renderAll();
      $('modalContent').innerHTML=`<div class="coin-purchased"><h2 id="fighterModalTitle">🎉 구매 성공!</h2>${portrait(id,'mini-portrait modal-portrait')}<h3>${FIGHTERS[id].name}</h3><p>🪙 ${p.price.toLocaleString('ko-KR')}코인 사용 · 남은 코인 ${save.coins.toLocaleString('ko-KR')}</p>${awards.includes(FINAL_FIGHTER_ID)?'<p class="final-unlock">🏆 1~106번 수집 완료! 특별 보상 107번 자동 해금!</p>':''}<div class="modal-actions"><button class="primary-button" id="equipBought">이 캐릭터로 출전</button><button class="secondary-button" id="closeBought">닫기</button></div></div>`;
      $('equipBought').onclick=()=>{save.selected=id;persist();renderAll();$('fighterModal').classList.add('hidden');};
      $('closeBought').onclick=()=>{$('fighterModal').classList.add('hidden');};
    }));
  }
  $('coinShopCards').addEventListener('click',e=>{const b=e.target.closest('[data-coin-package]');if(b)openCoinPackage(Number(b.dataset.coinPackage));});
  function renderAll(){renderStats();renderCurrent();renderLadder();renderTarget();renderGacha();renderFilters();renderRoster();renderCoinShop();}
  function openFighter(i){inspected=i;const f=FIGHTERS[i],s=fighterStats(i),owned=save.owned.includes(i),v=Number(save.invested[i]||0),cost=xpCost(i);
    $('modalContent').innerHTML=`${portrait(i,'mini-portrait modal-portrait')}<span class="fighter-number">파이터 NO. ${String(i+1).padStart(3,'0')}</span><h2 id="fighterModalTitle">${f.name}</h2>${chip(i)}<p>${f.role} · 오른쪽 순서의 캐릭터일수록 더 강해져!</p><p class="attack-description">${attackType(i).icon} <b>${attackType(i).name}</b> · ${attackType(i).detail}</p><p>💚 3초마다 체력 +${f.tier>=6?100:40} (최대 체력까지)</p><p class="level-progress">${levelInfo(i)}</p><div class="stat-grid"><div class="stat-cell"><b>${s.hp}</b><small>❤️ 체력</small></div><div class="stat-cell"><b>${s.atk}</b><small>⚔ 공격력</small></div><div class="stat-cell"><b>${f.speed}</b><small>💨 이동속도</small></div></div><div class="modal-actions">${owned?`<button class="primary-button" id="equipFighter">${i===save.selected?'✓ 출전 중':'이 캐릭터로 출전하기'}</button>`:i===FINAL_FIGHTER_ID?`<p class="locked-message">🔒 최종 수집 보상 · ${baseOwnedCount()} / 106종 보유<br/>1~106번을 전부 획득하면 자동 해금!<br/>XP · 코인 · 승리 계단 · 뽑기로는 획득할 수 없어.</p>${progress(baseOwnedCount(),106,true)}`:`<p class="locked-message">🔒 해금에 필요한 XP: ${cost.toLocaleString()}<br/>모은 XP: ${v.toLocaleString()} / ${cost.toLocaleString()}</p>${progress(v,cost)}<button class="primary-button" id="focusFighter">⚡ 이 캐릭터 XP 모으기</button><p>또는 누적 ${ladderThreshold(i).toLocaleString()}승을 달성하면 자동 획득!</p><button class="primary-button" id="trialArena">⚔ 이 캐릭터로 아레나 체험전</button><small>보상·전적·XP·뽑기권 없음 · 개인전/더블 모드 가능</small>`}${i!==FINAL_FIGHTER_ID||owned?'<button class="secondary-button" id="tryFighter">🎯 이 캐릭터 체험하기</button>':''}</div>`;
    $('fighterModal').classList.remove('hidden');
    if(owned)$('equipFighter').onclick=()=>{save.selected=i;persist();$('fighterModal').classList.add('hidden');renderAll();};
    else if(i!==FINAL_FIGHTER_ID) {
      $('focusFighter').onclick=()=>{save.target=i;persist();$('fighterModal').classList.add('hidden');renderAll();window.scrollTo({top:0,behavior:'smooth'});};
      $('trialArena').onclick=()=>spawnGame(i);
    }
    if(i!==FINAL_FIGHTER_ID||owned)$('tryFighter').onclick=()=>openPracticeSelector(i);
  }
  function openPracticeSelector(i){
    if(i===FINAL_FIGHTER_ID&&!save.owned.includes(i))return;
    const f=FIGHTERS[i];inspected=i;
    $('modalContent').innerHTML=`${portrait(i,'mini-portrait practice-choice-portrait')}<h2 id="fighterModalTitle">${f.name} 체험하기</h2><p>보유하지 않은 캐릭터도 마음껏 써 볼 수 있어!<br/>체험 중 죽어도 손해 없고 XP·승수·이용권도 변하지 않아.</p><div class="practice-options">${PRACTICE_MODES.map(m=>`<button class="practice-option" data-practice="${m.id}"><span class="practice-option-icon">${m.icon}</span><span class="practice-option-copy"><b>${m.title}</b><small>${m.detail}</small></span><span class="practice-option-arrow">➜</span></button>`).join('')}</div><div class="modal-actions"><button class="primary-button" id="goArenaFromPractice">⚔ 이 캐릭터로 아레나 가기</button>${!save.owned.includes(i)?'<small>미보유 캐릭터: 보상·전적·XP·뽑기권 없는 체험전</small>':''}</div>`;
    $('fighterModal').classList.remove('hidden');
    $('modalContent').querySelectorAll('[data-practice]').forEach(b=>b.onclick=()=>startPractice(i,b.dataset.practice));
    $('goArenaFromPractice').onclick=()=>spawnGame(i);
  }
  $('activeFighter').addEventListener('click',()=>openFighter(save.selected));
  $('rosterGrid').addEventListener('click',e=>{const t=e.target.closest('[data-try]');if(t){openPracticeSelector(Number(t.dataset.try));return;}const b=e.target.closest('[data-fighter]');if(b)openFighter(Number(b.dataset.fighter));});
  $('filterBar').addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;filter=b.dataset.filter;renderFilters();renderRoster();});
  $('gachaCards').addEventListener('click',e=>{const b=e.target.closest('[data-roll]');if(b)rollTicket(b.dataset.roll);});
  $('closeModal').onclick=()=> $('fighterModal').classList.add('hidden');
  $('fighterModal').addEventListener('click',e=>{if(e.target===$('fighterModal'))$('fighterModal').classList.add('hidden');});
  function setMode(m){mode=m;for(const k of ['solo','duo']){const btn=$(k+'Mode');btn.classList.toggle('active',k===mode);btn.setAttribute('aria-pressed',String(k===mode));}}
  $('soloMode').onclick=()=>setMode('solo');$('duoMode').onclick=()=>setMode('duo');

  const canvas=$('arena'),ctx=canvas.getContext('2d'),W=1000,H=600;
  function fitCanvas(){const b=canvas.getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,2);const w=Math.max(1,Math.round(b.width*dpr)),h=Math.max(1,Math.round(b.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}}
  window.addEventListener('resize',()=>{if(game){fitCanvas();draw();}});
  const held={up:false,down:false,left:false,right:false,attack:false};
  const joystick={x:0,y:0,active:false,pointerId:null};
  const joystickPad=$('moveJoystick'),joystickKnob=$('joystickKnob');
  function resetJoystick(){joystick.x=0;joystick.y=0;joystick.active=false;joystick.pointerId=null;joystickKnob.style.transform='translate(-50%, -50%)';}
  function moveJoystick(e){
    const rect=joystickPad.getBoundingClientRect(),radius=Math.min(rect.width,rect.height)*.36;
    const x=e.clientX-(rect.left+rect.width/2),y=e.clientY-(rect.top+rect.height/2);
    const factor=Math.max(1,Math.hypot(x,y)/radius);
    joystick.x=x/factor/radius;joystick.y=y/factor/radius;
    joystickKnob.style.transform=`translate(calc(-50% + ${joystick.x*radius}px), calc(-50% + ${joystick.y*radius}px))`;
  }
  joystickPad.addEventListener('pointerdown',e=>{
    e.preventDefault();joystickPad.setPointerCapture(e.pointerId);joystick.active=true;joystick.pointerId=e.pointerId;moveJoystick(e);
  });
  joystickPad.addEventListener('pointermove',e=>{if(joystick.active&&e.pointerId===joystick.pointerId)moveJoystick(e);});
  for(const event of ['pointerup','pointercancel','lostpointercapture'])joystickPad.addEventListener(event,e=>{if(e.pointerId===joystick.pointerId){e.preventDefault();resetJoystick();}});
  const keyMap={ArrowUp:'up',KeyW:'up',ArrowDown:'down',KeyS:'down',ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',Space:'attack'};
  function updateHeld(k,val){if(k in held)held[k]=val;document.querySelectorAll(`[data-key="${k}"]`).forEach(btn=>btn.classList.toggle('active',val));}
  window.addEventListener('keydown',e=>{const k=keyMap[e.code];if(game&&k){e.preventDefault();updateHeld(k,true);}if(e.code==='Escape'){$('fighterModal').classList.add('hidden');}});
  window.addEventListener('keyup',e=>{const k=keyMap[e.code];if(k){e.preventDefault();updateHeld(k,false);}});
  window.addEventListener('blur',()=>{for(const k in held)updateHeld(k,false);resetJoystick();});
  for(const btn of document.querySelectorAll('[data-key]')){
    const k=btn.dataset.key;
    btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.setPointerCapture(e.pointerId);updateHeld(k,true);});
    for(const event of ['pointerup','pointercancel','lostpointercapture'])btn.addEventListener(event,e=>{e.preventDefault();updateHeld(k,false);});
  }
  function random(min,max){return min+Math.random()*(max-min);}
  function alive(e){return e.hp>0;}
  function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y);}
  // Any fighter, including the hidden hero, can appear regardless of level.
  function pickEnemyFighter(){return Math.floor(Math.random()*(save.owned.includes(FINAL_FIGHTER_ID)?FIGHTERS.length:FINAL_FIGHTER_ID));}
  function makeEntity(id,x,y,team,isPlayer=false){const f=FIGHTERS[id],stats=isPlayer?fighterStats(id):{level:1,hp:f.hp,atk:f.atk},scale=id>=101?1:isPlayer?1.20:(team===0?.91:.83),maxHp=Math.round(stats.hp*scale);
    return {id,team,x,y,dx:1,dy:0,r:21,maxHp,hp:maxHp,regenElapsed:0,poisonSources:new Map(),level:stats.level,atk:id>=100?stats.atk:Math.max(9,Math.round(stats.atk*(isPlayer?1.1:.81))),speed:f.speed*(isPlayer?1:.79),range:f.range+35,cd:random(0,.5),time:random(0,10),kills:0,isPlayer,color:team===0?'#7dffbb':team===1?'#ff8ca2':'#fbd06b',f};
  }
  function spawnGame(fighterId=save.selected){
    if(fighterId===FINAL_FIGHTER_ID&&!save.owned.includes(fighterId))return;
    if(raf)cancelAnimationFrame(raf);
    const trial=!save.owned.includes(fighterId);
    const map=MAPS[Math.floor(Math.random()*MAPS.length)],spawns=[[110,300],[890,300],[510,85],[510,515],[180,90],[815,515]];
    let actors=[];
    actors.push(makeEntity(fighterId,...spawns[0],0,true));
    if(mode==='duo'){
      actors.push(makeEntity(pickEnemyFighter(),...spawns[1],0));
      actors.push(makeEntity(pickEnemyFighter(),...spawns[2],1));actors.push(makeEntity(pickEnemyFighter(),...spawns[3],1));
      actors.push(makeEntity(pickEnemyFighter(),...spawns[4],2));actors.push(makeEntity(pickEnemyFighter(),...spawns[5],2));
    } else for(let i=1;i<6;i++)actors.push(makeEntity(pickEnemyFighter(),...spawns[i],i));
    game={mode,trial,fighterId,map,actors,bullets:[],particles:[],effects:[],waves:[],time:90,ended:false,lastTs:0,feed:[],frame:0};
    for(const k in held)updateHeld(k,false);resetJoystick();
    $('homeScreen').classList.add('hidden');$('battleScreen').classList.remove('hidden');$('resultOverlay').classList.add('hidden');
    $('quitBattle').textContent='✕ 나가기';
    $('battleModeLabel').textContent=`${trial?'🎮 체험전 · ':''}${mode==='solo'?'⚔ 개인전':'🤝 더블 모드'}`;$('battleStatus').textContent=`${map.name} · ${trial?'보상·전적 없음':'마지막까지 살아남자!'}`;
    $('fighterModal').classList.add('hidden');
    $('myFighterName').textContent=`${FIGHTERS[fighterId].name} · Lv.${fighterLevel(fighterId)}`;updateHud();draw();raf=requestAnimationFrame(loop);
  }
  function makePracticeTarget(x,y,hp,name,icon,canAttack=false){
    const e=makeEntity(0,x,y,1);
    Object.assign(e,{f:{name,icon},hp,maxHp:hp,atk:canAttack?10:0,speed:canAttack?78:0,range:270,r:hp===2000?20:48,
      trainingDummy:!canAttack,trainingMonster:true,invuln:0,color:canAttack?'#ff976e':'#ffd37a',cd:canAttack?1:0});
    return e;
  }
  function startPractice(fighterId,practiceId){
    if(fighterId===FINAL_FIGHTER_ID&&!save.owned.includes(fighterId))return;
    const practice=PRACTICE_MODES.find(m=>m.id===practiceId);if(!practice)return;
    if(raf)cancelAnimationFrame(raf);
    const player=makeEntity(fighterId,105,300,0,true);player.invuln=0;
    const actors=[player];
    if(practiceId==='crowd'){
      for(let row=0;row<5;row++)for(let col=0;col<5;col++)actors.push(makePracticeTarget(355+col*113,92+row*103,2000,`표적 ${row*5+col+1}`,'🎯'));
    }else if(practiceId==='giant')actors.push(makePracticeTarget(700,300,100000,'초거대 괴물','🗿'));
    else actors.push(makePracticeTarget(700,300,5000,'전투 괴물','👹',true));
    game={mode:'practice',practice:true,practiceId,practice,practiceFighterId:fighterId,map:practice.map,actors,bullets:[],particles:[],effects:[],waves:[],
      time:Infinity,ended:false,lastTs:0,feed:[],frame:0,practiceKills:0,practiceDeaths:0,practiceCycles:0,respawnCountdown:null};
    $('fighterModal').classList.add('hidden');
    $('homeScreen').classList.add('hidden');$('battleScreen').classList.remove('hidden');$('resultOverlay').classList.add('hidden');
    for(const k in held)updateHeld(k,false);resetJoystick();
    $('battleModeLabel').textContent=`🎯 ${practice.title}`;
    $('quitBattle').textContent='← 체험 끝내기';
    $('myFighterName').textContent=`${FIGHTERS[fighterId].name} · Lv.${fighterLevel(fighterId)}`;
    updateHud();draw();raf=requestAnimationFrame(loop);
  }
  function collides(x,y,r){if(x<r+13||y<r+13||x>W-r-13||y>H-r-13)return true;
    return game.map.blocks.some(b=>{const nearX=Math.max(b.x,Math.min(x,b.x+b.w)),nearY=Math.max(b.y,Math.min(y,b.y+b.h));return (x-nearX)**2+(y-nearY)**2<(r+3)**2;});
  }
  function moveEntity(e,dx,dy,dt){if(!alive(e))return;const length=Math.hypot(dx,dy);if(length>.001){dx/=length;dy/=length;e.dx=dx;e.dy=dy;}
    const speed=e.speed*(e.slowTime>0?.55:1);
    const mx=dx*speed*dt,my=dy*speed*dt;
    if(!collides(e.x+mx,e.y,e.r))e.x+=mx;
    if(!collides(e.x,e.y+my,e.r))e.y+=my;
  }
  function nearestEnemy(actor){let target=null,best=Infinity;for(const other of game.actors){if(other===actor||!alive(other)||other.team===actor.team)continue;const d=dist(actor,other);if(d<best){best=d;target=other;}}return target;}
  function emitProjectile(actor,angle,damage,piercing=false,large=false,special=false){
    const speed=piercing?1150:510;
    game.bullets.push({x:actor.x+Math.cos(angle)*24,y:actor.y+Math.sin(angle)*24,
      vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed,team:actor.team,from:actor,damage,
      r:piercing?(special?8:6):special?9:large?10:7,ttl:piercing?Infinity:actor.range/510+.20,
      color:special?'#ffe784':piercing?'#f9b8ff':actor.color,pierce:piercing,bouncesLeft:piercing?Infinity:0,
      hitActors:piercing?new Map():null});
    return game.bullets[game.bullets.length-1];
  }
  function launchAttack(actor,angle,damage,kind,settings={}){
    const special=actor.isPlayer&&actor.level===5;
    const b=emitProjectile(actor,angle,damage,false,false,special);
    Object.assign(b,{kind,...settings});
    return b;
  }
  function splashAttack(actor,x,y,r,damage){
    for(const e of game.actors){
      if(!alive(e)||e.team===actor.team||e===actor||e.invuln||Math.hypot(e.x-x,e.y-y)>r+e.r)continue;
      hitEntity(e,{from:actor,damage});
    }
  }
  function explodeBomb(b){
    splashAttack(b.from,b.x,b.y,84,b.damage);
    game.effects.push({kind:'explosion',x:b.x,y:b.y,color:'#ffb25d',r:90,ttl:.36,maxTtl:.36});
    for(let i=0;i<12;i++)game.particles.push({x:b.x,y:b.y,vx:random(-130,130),vy:random(-130,130),ttl:.46,color:'#ffa24a',size:random(3,7)});
  }
  function landPoisonBomb(b){
    const target=b.target;
    if(!alive(target))return;
    if(!target.poisonSources.has(b.from))target.poisonSources.set(b.from,0);
    game.effects.push({kind:'explosion',x:target.x,y:target.y,color:'#a6fa65',r:65,ttl:.42,maxTtl:.42});
    for(let i=0;i<10;i++)game.particles.push({x:target.x,y:target.y,vx:random(-75,75),vy:random(-80,30),ttl:.65,color:'#83f35b',size:random(3,7)});
    game.particles.push({x:target.x,y:target.y-49,vx:0,vy:-40,ttl:.85,color:'#c6ff7c',text:'☣️ 독 감염!'});
  }
  function fire(actor,target){if(!alive(actor)||actor.cd>0)return;
    let angle;
    if(target)angle=Math.atan2(target.y-actor.y,target.x-actor.x);else angle=Math.atan2(actor.dy,actor.dx);
    if(!actor.isPlayer&&actor.id!==FINAL_FIGHTER_ID)angle+=random(-.12,.12);
    // Hidden character #101 hits every opponent anywhere in the arena.
    // Allies and the attacker are excluded, including in duo mode.
    if(actor.id===100){
      const victims=game.actors.filter(e=>alive(e)&&e!==actor&&e.team!==actor.team&&!e.invuln);
      for(const e of victims)hitEntity(e,{from:actor,damage:actor.level===5?60:50});
      game.effects.push({kind:'global',x:actor.x,y:actor.y,color:'#76ffe9',ttl:.52,maxTtl:.52});
      game.particles.push({x:actor.x,y:actor.y-52,vx:0,vy:-48,ttl:.72,color:'#c6fff2',text:'👑 전장 전체 공격!'});
      actor.cd=1.5;
      return;
    }
    // Hero #102: a triangle (550 long, 540 wide at its base) covers ~1/4
    // of a 1000x600 arena. Each opponent within it takes one 100-damage hit.
    if(actor.id===101){
      const length=550,halfWidth=270,ux=Math.cos(angle),uy=Math.sin(angle);
      for(const e of game.actors){
        if(!alive(e)||e===actor||e.team===actor.team||e.invuln)continue;
        const dx=e.x-actor.x,dy=e.y-actor.y;
        const forward=dx*ux+dy*uy,side=Math.abs(-dx*uy+dy*ux);
        if(forward>=-e.r&&forward<=length+e.r&&side<=(Math.max(0,forward)/length)*halfWidth+e.r){
          hitEntity(e,{from:actor,damage:actor.atk});
        }
      }
      game.effects.push({kind:'poison',x:actor.x,y:actor.y,angle,length,halfWidth,color:'#8cff79',ttl:1.25,maxTtl:1.25});
      game.particles.push({x:actor.x,y:actor.y-48,vx:0,vy:-42,ttl:.72,color:'#a4ff83',text:'☣️ 독가스 분사!'});
      actor.cd=1.75;
      return;
    }
    // Superhero #103: homing poison bombs strike everyone except the caster,
    // even teammates. Each infected target loses 221 HP every second until KO.
    if(actor.id===102){
      for(const e of game.actors){
        if(!alive(e)||e===actor)continue;
        game.bullets.push({kind:'poisonBomb',from:actor,target:e,team:actor.team,
          x:actor.x,y:actor.y,vx:0,vy:0,r:13,ttl:3.5,color:'#a0ff61'});
      }
      game.effects.push({kind:'ring',x:actor.x,y:actor.y,r:140,color:'#a4ff6f',ttl:.48,maxTtl:.48});
      game.particles.push({x:actor.x,y:actor.y-50,vx:0,vy:-47,ttl:.88,color:'#e2ff9c',text:'🧪 전장 독폭탄!'});
      actor.cd=3;
      return;
    }
    // Superhero #104: one circular shockwave reaches every arena edge and comes back.
    if(actor.id===103){
      const corners=[[0,0],[W,0],[0,H],[W,H]];
      const maxR=Math.max(...corners.map(([x,y])=>Math.hypot(x-actor.x,y-actor.y)))+30;
      game.waves.push({from:actor,x:actor.x,y:actor.y,r:0,lastR:0,maxR,speed:650,phase:'out',hitOut:new Set(),hitBack:new Set(),damage:actor.atk});
      game.particles.push({x:actor.x,y:actor.y-48,vx:0,vy:-45,ttl:.75,color:'#b5f7ff',text:'🌀 왕복 회오리!'});
      actor.cd=2.25;return;
    }
    // Superhero #105: ten simultaneously emitted ice spears, 36 degrees apart.
    if(actor.id===104){
      for(let i=0;i<10;i++){
        const a=angle+i*Math.PI/5;
        launchAttack(actor,a,actor.atk,'ice',{vx:Math.cos(a)*610,vy:Math.sin(a)*610,ttl:1.65,r:11,pierce:true,hitActors:new Map(),bouncesLeft:0,color:'#aeefff'});
      }
      game.particles.push({x:actor.x,y:actor.y-48,vx:0,vy:-48,ttl:.8,color:'#d6ffff',text:'❄️ 얼음 폭풍!'});
      actor.cd=1.7;return;
    }
    // Superhero #106: a single piercing laser projectile that ricochets.
    if(actor.id===105){
      const b=emitProjectile(actor,angle,actor.atk,true,false,actor.isPlayer&&actor.level===5);
      Object.assign(b,{kind:'ricochetLaser',vx:Math.cos(angle)*1150,vy:Math.sin(angle)*1150,
        ttl:4.0,r:12,color:'#ffdf9a',bouncesLeft:10,hitActors:new Map()});
      game.particles.push({x:actor.x,y:actor.y-48,vx:0,vy:-45,ttl:.75,color:'#fff2b2',text:'🔱 관통 반사 레이저!'});
      actor.cd=1.6;return;
    }
    // #107: aimed straight at the nearest enemy when fired; no mid-flight homing.
    // Only collisions with walls or arena obstacles reflect the laser.
    if(actor.id===FINAL_FIGHTER_ID){
      const b=emitProjectile(actor,angle,actor.atk,true,false,actor.isPlayer&&actor.level===5);
      Object.assign(b,{kind:'legendLaser',vx:Math.cos(angle)*1060,vy:Math.sin(angle)*1060,
        ttl:22,r:13,color:'#fff0a9',bouncesLeft:Infinity,hitActors:new Map(),pierce:true});
      game.particles.push({x:actor.x,y:actor.y-48,vx:0,vy:-45,ttl:.75,color:'#fff6a6',text:'🌠 초전설 반사 레이저!'});
      actor.cd=2.1;return;
    }
    // Character #100: ten rapid shots on one trajectory, each dealing 1/10 damage.
    // Shots never expire in a live match, pierce enemies and ricochet indefinitely.
    if(actor.id===99){
      emitProjectile(actor,angle,actor.atk/10,true,false,actor.isPlayer&&actor.level===5);
      actor.burst={angle,remaining:9,untilNext:.075};
      actor.cd=1.5;
      return;
    }
    const type=actor.id%10,attack=ATTACK_TYPES[type],special=actor.isPlayer&&actor.level===5;
    const ux=Math.cos(angle),uy=Math.sin(angle);
    if(type===0){ // A broad close-range sword swing.
      for(const e of game.actors){
        if(!alive(e)||e.team===actor.team||e===actor||e.invuln)continue;
        const a=Math.atan2(e.y-actor.y,e.x-actor.x),diff=Math.atan2(Math.sin(a-angle),Math.cos(a-angle));
        if(dist(actor,e)<95+e.r&&Math.abs(diff)<.95)hitEntity(e,{from:actor,damage:actor.atk*1.15});
      }
      game.effects.push({kind:'slash',x:actor.x,y:actor.y,angle,color:special?'#ffe784':'#b7f5ff',ttl:.23,maxTtl:.23});
    }else if(type===1){ // Slow moving, repeatedly damaging tornado.
      launchAttack(actor,angle,actor.atk*.34,'tornado',{vx:ux*155,vy:uy*155,r:37,ttl:1.9,pierce:true,hitActors:new Map(),color:special?'#ffe784':'#84e5f5'});
    }else if(type===2){ // Flying grappling hook with a visible rope.
      launchAttack(actor,angle,actor.atk*.95,'hook',{vx:ux*565,vy:uy*565,ttl:.66,r:13,color:special?'#ffe784':'#ccd5e6'});
    }else if(type===3){ // Boomerang only damages on its return trip.
      launchAttack(actor,angle,actor.atk,'boomerang',{vx:ux*430,vy:uy*430,ttl:2.15,r:16,pierce:true,hitActors:new Map(),returning:false,age:0,color:special?'#ffe784':'#ffc774'});
    }else if(type===4){ // Three short flames.
      for(const offset of [-.27,0,.27])launchAttack(actor,angle+offset,actor.atk*.48,'flame',{vx:Math.cos(angle+offset)*340,vy:Math.sin(angle+offset)*340,ttl:.55,r:15,color:special?'#ffe784':'#ff793d'});
    }else if(type===5){ // Instant chain lightning.
      const seen=new Set(),points=[{x:actor.x,y:actor.y}];
      let previous=actor;
      for(let i=0;i<3;i++){
        const limit=i===0?attack.range:175;
        const victims=game.actors.filter(e=>alive(e)&&e.team!==actor.team&&!seen.has(e)&&!e.invuln&&dist(e,previous)<=limit);
        victims.sort((a,b)=>dist(a,previous)-dist(b,previous));
        if(!victims.length)break;
        const e=victims[0];seen.add(e);points.push({x:e.x,y:e.y});
        hitEntity(e,{from:actor,damage:actor.atk*(i===0?1:i===1?.65:.4)});
        previous=e;
      }
      game.effects.push({kind:'lightning',points,color:special?'#ffe784':'#b3d0ff',ttl:.25,maxTtl:.25});
    }else if(type===6){ // Radial shockwave.
      splashAttack(actor,actor.x,actor.y,attack.range,actor.atk*.93);
      game.effects.push({kind:'ring',x:actor.x,y:actor.y,r:attack.range,color:special?'#ffe784':'#a5ffcf',ttl:.4,maxTtl:.4});
    }else if(type===7){ // Piercing ice that also slows enemies.
      launchAttack(actor,angle,actor.atk*.95,'ice',{vx:ux*610,vy:uy*610,ttl:.67,r:10,pierce:true,hitActors:new Map(),color:special?'#ffe784':'#aeeeff'});
    }else if(type===8){ // Explosive thrown bomb.
      launchAttack(actor,angle,actor.atk*1.07,'bomb',{vx:ux*350,vy:uy*350,ttl:.8,r:14,color:special?'#ffe784':'#ffb15b'});
    }else{ // Laser hits all opponents standing in the beam.
      const endX=actor.x+ux*attack.range,endY=actor.y+uy*attack.range;
      for(const e of game.actors){
        if(!alive(e)||e.team===actor.team||e===actor||e.invuln)continue;
        const along=(e.x-actor.x)*ux+(e.y-actor.y)*uy;
        const sideways=Math.abs((e.x-actor.x)*uy-(e.y-actor.y)*ux);
        if(along>=0&&along<=attack.range&&sideways<e.r+13)hitEntity(e,{from:actor,damage:actor.atk*1.05});
      }
      game.effects.push({kind:'beam',x:actor.x,y:actor.y,x2:endX,y2:endY,color:special?'#ffe784':'#ff94ed',ttl:.2,maxTtl:.2});
    }
    actor.cd=attack.cd+(actor.isPlayer?-.08:random(.08,.25));
    if(special)game.particles.push({x:actor.x,y:actor.y-38,vx:0,vy:-55,ttl:.65,color:'#ffe784',text:'✨ 특수 공격!'});
    for(let i=0;i<4;i++)game.particles.push({x:actor.x+ux*20,y:actor.y+uy*20,vx:random(-40,40),vy:random(-40,40),ttl:.24,color:special?'#ffe784':'#fff3ab',size:random(2,5)});
  }
  function addFeed(text){game.feed.unshift({text,ttl:3.2});game.feed=game.feed.slice(0,3);$('battleFeed').innerHTML=game.feed.map(f=>`<div class="feed-item">${f.text}</div>`).join('');}
  function hitEntity(victim,bullet){victim.hp=Math.max(0,victim.hp-bullet.damage);
    game.particles.push({x:victim.x,y:victim.y-34,vx:random(-12,12),vy:-35,ttl:.6,color:'#fff0a8',text:`-${Math.round(bullet.damage)}`});
    if(!alive(victim)){bullet.from.kills++;if(game.practice&&victim.team!==0)game.practiceKills++;addFeed(`${bullet.from.f.icon} ${bullet.from.f.name} ➜ ${victim.f.icon} ${victim.f.name}`);for(let i=0;i<12;i++)game.particles.push({x:victim.x,y:victim.y,vx:random(-110,110),vy:random(-110,110),ttl:.6,color:victim.color,size:random(3,7)});}
  }
  function updatePracticeLifecycle(dt){
    const player=game.actors[0];
    if(!alive(player)){
      game.practiceDeaths++;
      player.hp=player.maxHp;player.regenElapsed=0;player.poisonSources.clear();player.x=105;player.y=300;player.cd=0;player.invuln=2;
      game.bullets=game.bullets.filter(b=>b.team===0);
      addFeed('💚 체험이니까 바로 부활! 기록 손실 없음');
    }
    if(game.actors.slice(1).every(e=>!alive(e))){
      if(game.respawnCountdown===null){game.respawnCountdown=1.5;addFeed('🎉 모두 처치! 표적들이 곧 다시 나타나!');}
      else if((game.respawnCountdown-=dt)<=0){
        for(const e of game.actors.slice(1)){e.hp=e.maxHp;e.poisonSources.clear();e.cd=game.practiceId==='duel'?1:0;}
        game.practiceCycles++;game.respawnCountdown=null;
      }
    }else game.respawnCountdown=null;
  }
  function update(dt){game.frame++;if(!game.practice)game.time=Math.max(0,game.time-dt);
    for(const e of game.actors){if(e.invuln>0)e.invuln=Math.max(0,e.invuln-dt);if(e.slowTime>0)e.slowTime=Math.max(0,e.slowTime-dt);if(!alive(e))continue;
      if(!e.trainingMonster){
        e.regenElapsed+=dt;
        while(e.regenElapsed>=3){
          e.regenElapsed-=3;
          if(e.hp<e.maxHp){
            const recovered=Math.min(e.f.tier>=6?100:40,e.maxHp-e.hp);
            e.hp+=recovered;
            game.particles.push({x:e.x,y:e.y-38,vx:0,vy:-42,ttl:.65,color:'#8dffc1',text:`+${Math.round(recovered)}`});
          }
        }
      }
      for(const [source,elapsed] of e.poisonSources){
        let nextTick=elapsed+dt;
        while(nextTick>=1&&alive(e)){
          nextTick-=1;
          hitEntity(e,{from:source,damage:221});
        }
        e.poisonSources.set(source,nextTick);
      }
      if(!alive(e))continue;
      e.cd=Math.max(0,e.cd-dt);e.time+=dt;
      if(e.burst&&e.burst.remaining>0){
        e.burst.untilNext-=dt;
        while(e.burst.remaining>0&&e.burst.untilNext<=0){
          emitProjectile(e,e.burst.angle,e.atk/10,true,false,e.isPlayer&&e.level===5);
          e.burst.remaining--;e.burst.untilNext+=.075;
        }
      }
      if(e.isPlayer){let dx=joystick.active?joystick.x:Number(held.right)-Number(held.left),dy=joystick.active?joystick.y:Number(held.down)-Number(held.up);moveEntity(e,dx,dy,dt);if(held.attack)fire(e,nearestEnemy(e));}
      else if(e.trainingDummy){continue;}
      else {const target=nearestEnemy(e);if(!target)continue;const d=dist(e,target),a=Math.atan2(target.y-e.y,target.x-e.x),turn=Math.sin(e.time*1.2+e.id)*.4;
        const attackRange=e.id>=99?e.range:ATTACK_TYPES[e.id%10].range,desired=Math.min(188,Math.max(75,attackRange*.73));
        let dx=Math.cos(a+turn)*(d>desired?1:d<desired*.65?-.55:.08),dy=Math.sin(a+turn)*(d>desired?1:d<desired*.65?-.55:.08);
        if(d<280){dx+=Math.cos(a+Math.PI/2)*.4*Math.sin(e.time);dy+=Math.sin(a+Math.PI/2)*.4*Math.sin(e.time);}
        moveEntity(e,dx,dy,dt);if(d<attackRange&&e.cd===0)fire(e,target);
      }
    }
    for(let i=game.bullets.length-1;i>=0;i--){const b=game.bullets[i];
      if(b.kind==='poisonBomb'){
        b.ttl-=dt;
        if(!alive(b.target)||b.ttl<=0){game.bullets.splice(i,1);continue;}
        const dx=b.target.x-b.x,dy=b.target.y-b.y,d=Math.hypot(dx,dy),travel=730*dt;
        if(d<=travel+b.target.r){landPoisonBomb(b);game.bullets.splice(i,1);}
        else {b.vx=dx/d*730;b.vy=dy/d*730;b.x+=b.vx*dt;b.y+=b.vy*dt;}
        continue;
      }
      const prevX=b.x,prevY=b.y;
      b.ttl-=dt;let remove=b.ttl<=0;
      if(b.kind==='boomerang'){
        b.age+=dt;
        if(!b.returning&&b.age>.62)b.returning=true;
        if(b.returning){
          const d=dist(b,b.from);
          if(d<32||!alive(b.from))remove=true;
          else{b.vx=(b.from.x-b.x)/d*455;b.vy=(b.from.y-b.y)/d*455;}
        }
      }
      if(remove&&b.kind==='bomb')explodeBomb(b);
      let nextX=b.x+b.vx*dt,nextY=b.y+b.vy*dt;
      if(!remove&&b.kind!=='boomerang'&&collides(nextX,nextY,b.r*.3)){
        if(b.kind==='bomb'){explodeBomb(b);remove=true;}
        else if(b.pierce&&b.bouncesLeft>0){
          const crossX=collides(nextX,b.y,b.r*.3),crossY=collides(b.x,nextY,b.r*.3);
          if(crossX||(!crossX&&!crossY))b.vx=-b.vx;
          if(crossY||(!crossX&&!crossY))b.vy=-b.vy;
          if(Number.isFinite(b.bouncesLeft))b.bouncesLeft--;
          nextX=b.x+b.vx*dt;nextY=b.y+b.vy*dt;
          if(collides(nextX,nextY,b.r*.3)){nextX=b.x;nextY=b.y;}
          game.particles.push({x:b.x,y:b.y,vx:random(-55,55),vy:random(-55,55),ttl:.16,color:'#f7caff',size:3});
        }else remove=true;
      }
      if(!remove&&b.kind==='boomerang'&&!b.returning&&collides(nextX,nextY,b.r*.3)){b.returning=true;nextX=b.x;nextY=b.y;}
      b.x=nextX;b.y=nextY;
      if(!remove)for(const e of game.actors){
        if(!alive(e)||e.team===b.team||e===b.from)continue;
        // Swept collision avoids skipping a target between frames at laser speed.
        let hitDist=dist(b,e);
        if(b.kind==='legendLaser'){
          const sx=b.x-prevX,sy=b.y-prevY,len2=sx*sx+sy*sy;
          const t=len2>0?Math.max(0,Math.min(1,((e.x-prevX)*sx+(e.y-prevY)*sy)/len2)):0;
          hitDist=Math.hypot(e.x-(prevX+t*sx),e.y-(prevY+t*sy));
        }
        if(hitDist<e.r+b.r){
          if(b.kind==='boomerang'&&!b.returning)continue;
          if(b.hitActors&&(b.kind==='ricochetLaser'?b.hitActors.has(e):game.frame-(b.hitActors.get(e)??-Infinity)<16))continue;
          if(b.kind==='bomb'){explodeBomb(b);remove=true;break;}
          if(!e.invuln)hitEntity(e,b);
          if(b.kind==='ice')e.slowTime=Math.max(e.slowTime||0,1.6);
          if(b.kind==='hook'&&alive(e)){
            const d=dist(e,b.from),pull=Math.min(65,Math.max(0,d-35));
            if(d>0){const nx=e.x+(b.from.x-e.x)/d*pull,ny=e.y+(b.from.y-e.y)/d*pull;
              if(!collides(nx,e.y,e.r))e.x=nx;
              if(!collides(e.x,ny,e.r))e.y=ny;
            }
            game.effects.push({kind:'pull',x:e.x,y:e.y,color:'#e7f0ff',r:32,ttl:.28,maxTtl:.28});
          }
          if(b.pierce)b.hitActors.set(e,game.frame);else{remove=true;break;}
        }
      }
      if(remove)game.bullets.splice(i,1);
    }
    // Advance the outbound and returning rings; each victim is hit once per phase.
    for(let i=game.waves.length-1;i>=0;i--){
      const wave=game.waves[i],oldR=wave.r;
      wave.r+=wave.phase==='out'?wave.speed*dt:-wave.speed*dt;
      if(wave.phase==='out'&&wave.r>=wave.maxR){wave.r=wave.maxR;wave.phase='back';}
      const targets=wave.r>=wave.maxR?wave.hitOut:(wave.phase==='out'?wave.hitOut:wave.hitBack);
      const lo=Math.min(oldR,wave.r)-27,hi=Math.max(oldR,wave.r)+27;
      for(const e of game.actors){
        if(!alive(e)||e===wave.from||e.team===wave.from.team||e.invuln||targets.has(e))continue;
        const radius=Math.hypot(e.x-wave.x,e.y-wave.y);
        if(radius+e.r>=lo&&radius-e.r<=hi){hitEntity(e,{from:wave.from,damage:wave.damage});targets.add(e);}
      }
      if(wave.phase==='back'&&wave.r<=0)game.waves.splice(i,1);
    }
    for(let i=game.effects.length-1;i>=0;i--){game.effects[i].ttl-=dt;if(game.effects[i].ttl<=0)game.effects.splice(i,1);}
    for(let i=game.particles.length-1;i>=0;i--){const p=game.particles[i];p.x+=(p.vx||0)*dt;p.y+=(p.vy||0)*dt;p.ttl-=dt;if(p.ttl<=0)game.particles.splice(i,1);}
    for(const f of game.feed)f.ttl-=dt;
    if(game.frame%20===0){game.feed=game.feed.filter(f=>f.ttl>0);$('battleFeed').innerHTML=game.feed.map(f=>`<div class="feed-item">${f.text}</div>`).join('');}
    if(game.practice){updatePracticeLifecycle(dt);return;}
    const living=game.actors.filter(alive),teams=new Set(living.map(a=>a.team));
    if(teams.size<=1){finishGame(teams.has(0),false);return;}
    if(game.mode==='solo'&&!alive(game.actors[0])){finishGame(false,false);return;}
    if(game.time===0){const teamScores=new Map();for(const e of living)teamScores.set(e.team,(teamScores.get(e.team)||0)+e.hp/e.maxHp);const best=[...teamScores.entries()].sort((a,b)=>b[1]-a[1])[0]?.[0];finishGame(best===0,true);return;}
  }
  function updateHud(){if(!game)return;const p=game.actors[0],seconds=Math.ceil(game.time);$('battleTimer').textContent=game.practice?'∞':`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
    $('aliveLabel').textContent=game.practice?(game.practiceId==='crowd'?`표적 ${game.actors.slice(1).filter(alive).length}/25`:'연습 중'):`생존 ${game.actors.filter(alive).length}/6`;
    $('myHealthFill').style.width=`${pct(p.hp,p.maxHp)}%`;$('myHealthText').textContent=`${Math.ceil(p.hp)} / ${p.maxHp}`;
    if(game.practice){
      const target=game.actors[1],targetInfo=game.practiceId==='crowd'?`표적 처치 ${game.practiceKills}명`:`괴물 HP ${Math.ceil(target.hp).toLocaleString()} / ${target.maxHp.toLocaleString()}`;
      $('battleStatus').textContent=`${targetInfo} · 체험 중 사망 ${game.practiceDeaths}회 · 보상/벌점 없음`;return;
    }
    const battleInfo=game.mode==='duo'?`우리 팀 ${game.actors.filter(a=>a.team===0&&alive(a)).length}명 생존 · 나의 처치 ${p.kills}`:`나의 처치 ${p.kills}명 · 마지막 1명이 승리`;
    $('battleStatus').textContent=`${battleInfo}${game.trial?' · 체험전: 보상·전적 없음':''}`;
  }
  function rr(x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r);}
  function draw(){if(!game)return;fitCanvas();const map=game.map;ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle=map.color;ctx.fillRect(0,0,canvas.width,canvas.height);
    const zoom=Math.max(canvas.width/W,canvas.height/H)*1.65,visibleW=canvas.width/zoom,visibleH=canvas.height/zoom,player=game.actors[0];
    const cameraX=Math.max(0,Math.min(W-visibleW,player.x-visibleW/2)),cameraY=Math.max(0,Math.min(H-visibleH,player.y-visibleH/2));
    ctx.setTransform(zoom,0,0,zoom,-cameraX*zoom,-cameraY*zoom);
    ctx.strokeStyle='#ffffff12';ctx.lineWidth=1;for(let x=0;x<=W;x+=42){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}for(let y=0;y<=H;y+=42){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}
    ctx.save();ctx.strokeStyle='#ffffff30';ctx.lineWidth=6;ctx.setLineDash([15,12]);rr(15,15,W-30,H-30,18);ctx.stroke();ctx.setLineDash([]);
    ctx.strokeStyle='#ffffff14';ctx.lineWidth=4;ctx.beginPath();ctx.arc(500,300,120,0,2*Math.PI);ctx.stroke();ctx.beginPath();ctx.moveTo(500,20);ctx.lineTo(500,580);ctx.stroke();ctx.restore();
    for(const b of map.blocks){ctx.fillStyle='#0005';rr(b.x+5,b.y+8,b.w,b.h,15);ctx.fill();ctx.fillStyle=map.wall;rr(b.x,b.y,b.w,b.h,14);ctx.fill();ctx.fillStyle='#ffffff2f';rr(b.x+5,b.y+5,b.w-10,14,7);ctx.fill();ctx.strokeStyle='#ffffff28';ctx.lineWidth=3;rr(b.x+6,b.y+6,b.w-12,b.h-12,10);ctx.stroke();}
    for(const b of game.bullets){
      ctx.save();ctx.shadowColor=b.color;ctx.shadowBlur=10;
      if(b.kind==='ricochetLaser'||b.kind==='legendLaser'){
        const a=Math.atan2(b.vy,b.vx);ctx.translate(b.x,b.y);ctx.rotate(a);
        ctx.lineCap='round';ctx.strokeStyle=b.kind==='legendLaser'?'#ffe77c':'#ffa9f0';ctx.lineWidth=b.kind==='legendLaser'?30:22;ctx.globalAlpha=.35;
        ctx.beginPath();ctx.moveTo(-76,0);ctx.lineTo(15,0);ctx.stroke();
        ctx.globalAlpha=1;ctx.strokeStyle=b.kind==='legendLaser'?'#ffffff':'#fff4bd';ctx.lineWidth=b.kind==='legendLaser'?11:8;
        ctx.beginPath();ctx.moveTo(-67,0);ctx.lineTo(16,0);ctx.stroke();
      }else if(b.kind==='hook'){
        ctx.strokeStyle='#d6dbe6';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(b.from.x,b.from.y);ctx.lineTo(b.x,b.y);ctx.stroke();
        ctx.translate(b.x,b.y);ctx.rotate(Math.atan2(b.vy,b.vx));ctx.strokeStyle=b.color;ctx.lineWidth=6;
        ctx.beginPath();ctx.moveTo(-10,-11);ctx.lineTo(5,-11);ctx.arc(5,0,11,-Math.PI/2,Math.PI*.7);ctx.stroke();
      }else if(b.kind==='tornado'){
        ctx.translate(b.x,b.y);ctx.rotate(game.frame*.18);ctx.strokeStyle=b.color;ctx.lineWidth=6;
        for(let j=0;j<3;j++){ctx.beginPath();ctx.arc(0,0,13+j*10,j*1.4,j*1.4+Math.PI*1.35);ctx.stroke();}
      }else if(b.kind==='boomerang'){
        ctx.translate(b.x,b.y);ctx.rotate(game.frame*.3);ctx.strokeStyle=b.color;ctx.lineWidth=8;ctx.lineCap='round';ctx.lineJoin='round';
        ctx.beginPath();ctx.moveTo(-15,-14);ctx.lineTo(0,9);ctx.lineTo(15,-14);ctx.stroke();
      }else if(b.kind==='flame'){
        ctx.fillStyle=b.color;ctx.beginPath();ctx.ellipse(b.x,b.y,b.r*1.3,b.r*.7,Math.atan2(b.vy,b.vx),0,Math.PI*2);ctx.fill();
        ctx.fillStyle='#fff3aa';ctx.beginPath();ctx.arc(b.x,b.y,5,0,Math.PI*2);ctx.fill();
      }else if(b.kind==='ice'){
        ctx.translate(b.x,b.y);ctx.rotate(Math.atan2(b.vy,b.vx));ctx.fillStyle=b.color;ctx.strokeStyle='#f8ffff';ctx.lineWidth=2;
        ctx.beginPath();ctx.moveTo(20,0);ctx.lineTo(-4,-8);ctx.lineTo(-13,0);ctx.lineTo(-4,8);ctx.closePath();ctx.fill();ctx.stroke();
      }else if(b.kind==='poisonBomb'){
        ctx.fillStyle='#384a3a';ctx.strokeStyle='#b5ff6c';ctx.lineWidth=4;
        ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,Math.PI*2);ctx.fill();ctx.stroke();
        ctx.fillStyle='#d9ff95';ctx.font='17px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('☣',b.x,b.y);
      }else if(b.kind==='bomb'){
        ctx.fillStyle='#27384f';ctx.strokeStyle=b.color;ctx.lineWidth=4;ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,2*Math.PI);ctx.fill();ctx.stroke();
        ctx.fillStyle='#fff0a0';ctx.beginPath();ctx.arc(b.x+4,b.y-10,4,0,2*Math.PI);ctx.fill();
      }else{
        ctx.fillStyle=b.color;ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,2*Math.PI);ctx.fill();
      }
      ctx.restore();
    }
    // Blue/cyan swirling wave travelling to the arena boundaries and back.
    for(const wave of game.waves){
      ctx.save();ctx.translate(wave.x,wave.y);
      ctx.strokeStyle='#b7eaff';ctx.lineWidth=15;ctx.shadowColor='#80cbff';ctx.shadowBlur=25;ctx.globalAlpha=.58;
      ctx.beginPath();ctx.arc(0,0,Math.max(1,wave.r),0,Math.PI*2);ctx.stroke();
      ctx.globalAlpha=.94;ctx.lineWidth=6;
      for(let arm=0;arm<5;arm++){
        const offset=game.frame*.095+arm*Math.PI*2/5;
        ctx.beginPath();ctx.arc(0,0,Math.max(1,wave.r),offset,offset+.52);ctx.stroke();
      }
      ctx.restore();
    }
    for(const effect of game.effects){
      const alpha=Math.max(0,effect.ttl/effect.maxTtl),extent=1-alpha;
      ctx.save();ctx.globalAlpha=alpha;ctx.strokeStyle=effect.color;ctx.fillStyle=effect.color;ctx.shadowColor=effect.color;ctx.shadowBlur=18;
      if(effect.kind==='slash'){
        ctx.lineWidth=12;ctx.lineCap='round';ctx.beginPath();ctx.arc(effect.x,effect.y,78,effect.angle-.9,effect.angle+.9);ctx.stroke();
      }else if(effect.kind==='ring'||effect.kind==='explosion'||effect.kind==='pull'){
        const radius=effect.r*(effect.kind==='explosion'?.35+extent*.65:Math.max(.08,extent));
        ctx.lineWidth=effect.kind==='explosion'?12:7;ctx.beginPath();ctx.arc(effect.x,effect.y,radius,0,Math.PI*2);ctx.stroke();
        if(effect.kind==='explosion'){ctx.globalAlpha=alpha*.24;ctx.beginPath();ctx.arc(effect.x,effect.y,radius,0,Math.PI*2);ctx.fill();}
      }else if(effect.kind==='beam'){
        ctx.lineCap='round';ctx.lineWidth=19;ctx.globalAlpha=alpha*.4;ctx.beginPath();ctx.moveTo(effect.x,effect.y);ctx.lineTo(effect.x2,effect.y2);ctx.stroke();
        ctx.globalAlpha=alpha;ctx.strokeStyle='#fff4fe';ctx.lineWidth=5;ctx.stroke();
      }else if(effect.kind==='lightning'&&effect.points.length>1){
        ctx.lineWidth=6;ctx.lineJoin='round';ctx.beginPath();ctx.moveTo(effect.points[0].x,effect.points[0].y);
        for(let i=1;i<effect.points.length;i++){
          const a=effect.points[i-1],b=effect.points[i],dx=b.x-a.x,dy=b.y-a.y;
          ctx.lineTo(a.x+dx*.35-dy*.1,a.y+dy*.35+dx*.1);
          ctx.lineTo(a.x+dx*.65+dy*.1,a.y+dy*.65-dx*.1);
          ctx.lineTo(b.x,b.y);
        }
        ctx.stroke();ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.stroke();
      }else if(effect.kind==='global'){
        ctx.globalAlpha=alpha*.22;ctx.fillRect(0,0,W,H);
        ctx.globalAlpha=alpha;ctx.lineWidth=14;
        ctx.beginPath();ctx.arc(effect.x,effect.y,105+(1-alpha)*950,0,Math.PI*2);ctx.stroke();
        ctx.lineWidth=6;ctx.strokeStyle='#ffffff';ctx.strokeRect(21,21,W-42,H-42);
      }else if(effect.kind==='poison'){
        ctx.translate(effect.x,effect.y);ctx.rotate(effect.angle);
        const {length,halfWidth}=effect;
        const fog=ctx.createLinearGradient(0,0,length,0);
        fog.addColorStop(0,'#b8ffb300');fog.addColorStop(.35,'#78ed6fa8');fog.addColorStop(1,'#40bc50b5');
        ctx.globalAlpha=alpha*.68;ctx.fillStyle=fog;
        ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(length,-halfWidth);ctx.lineTo(length,halfWidth);ctx.closePath();ctx.fill();
        ctx.globalAlpha=alpha*.88;ctx.lineWidth=4;ctx.strokeStyle='#b2ff82';ctx.stroke();
        ctx.fillStyle='#cbff9e';
        for(let j=0;j<13;j++){
          const forward=length*(.17+(j%5)*.17),side=(Math.sin(j*2.7)*.72)*(forward/length)*halfWidth;
          ctx.globalAlpha=alpha*(.1+(j%3)*.055);
          ctx.beginPath();ctx.arc(forward,side,18+(j%4)*9,0,Math.PI*2);ctx.fill();
        }
      }
      ctx.restore();
    }
    for(const e of game.actors){if(!alive(e))continue;const {x,y,r}=e;ctx.fillStyle='#0007';ctx.beginPath();ctx.ellipse(x,y+18,r+7,9,0,0,Math.PI*2);ctx.fill();ctx.save();ctx.shadowColor=e.color;ctx.shadowBlur=e.isPlayer?23:5;ctx.fillStyle=e.color;ctx.beginPath();ctx.arc(x,y,r+6,0,Math.PI*2);ctx.fill();ctx.restore();ctx.fillStyle='#213452';ctx.beginPath();ctx.arc(x,y,r+1,0,Math.PI*2);ctx.fill();
      ctx.font='33px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(e.f.icon,x,y+1);
      if(e.poisonSources.size){
        ctx.save();ctx.strokeStyle='#98ff5d';ctx.lineWidth=3;ctx.shadowColor='#68ff35';ctx.shadowBlur=18;
        ctx.beginPath();ctx.arc(x,y,r+12+Math.sin(game.frame*.12)*2,0,Math.PI*2);ctx.stroke();
        ctx.font='16px serif';ctx.fillStyle='#bdff81';ctx.fillText('☣',x+r+12,y-r-10);ctx.restore();
      }
      if(e.isPlayer){ctx.strokeStyle='#fff09e';ctx.lineWidth=4;ctx.beginPath();ctx.arc(x,y,r+8,0,2*Math.PI);ctx.stroke();}
      ctx.textAlign='center';ctx.font='bold 12px sans-serif';ctx.lineWidth=3;ctx.strokeStyle='#081427';ctx.strokeText(e.isPlayer?'★ 나':e.team===0?'🤝 팀원':e.f.name,x,y-51);ctx.fillStyle='#fff';ctx.fillText(e.isPlayer?'★ 나':e.team===0?'🤝 팀원':e.f.name,x,y-51);
      ctx.fillStyle='#131b36';rr(x-30,y-42,60,9,5);ctx.fill();ctx.fillStyle=e.team===0?'#8afaac':e.team===1?'#fb8b9d':'#ffe08a';rr(x-29,y-41,58*(e.hp/e.maxHp),7,4);ctx.fill();
      if(game.practice&&e.trainingMonster&&game.practiceId!=='crowd'){ctx.textAlign='center';ctx.font='bold 13px sans-serif';ctx.lineWidth=3;ctx.strokeStyle='#081427';ctx.strokeText(`${Math.ceil(e.hp).toLocaleString()} HP`,x,y-68);ctx.fillStyle='#fffbd3';ctx.fillText(`${Math.ceil(e.hp).toLocaleString()} HP`,x,y-68);}
    }
    for(const p of game.particles){ctx.globalAlpha=Math.min(1,p.ttl*2.5);ctx.fillStyle=p.color;if(p.text){ctx.textAlign='center';ctx.font='bold 17px sans-serif';ctx.fillText(p.text,p.x,p.y);}else{ctx.beginPath();ctx.arc(p.x,p.y,p.size||3,0,Math.PI*2);ctx.fill();}}ctx.globalAlpha=1;
    ctx.setTransform(1,0,0,1,0,0);
    if(visibleW<750){
      const mw=112*Math.min(window.devicePixelRatio||1,2),mh=mw*.6,mx=canvas.width-mw-10,my=54;
      ctx.fillStyle='#07132ddc';rr(mx-5,my-5,mw+10,mh+10,10);ctx.fill();ctx.fillStyle=map.floor;rr(mx,my,mw,mh,6);ctx.fill();
      for(const e of game.actors){if(!alive(e))continue;ctx.fillStyle=e.color;ctx.beginPath();ctx.arc(mx+e.x/W*mw,my+e.y/H*mh,e.isPlayer?5:3,0,2*Math.PI);ctx.fill();}
      ctx.strokeStyle='#fff8';ctx.lineWidth=1;ctx.strokeRect(mx+cameraX/W*mw,my+cameraY/H*mh,visibleW/W*mw,visibleH/H*mh);
    }else{
      ctx.fillStyle='#05132599';rr(20,77,165,31,10);ctx.fill();ctx.font='bold 14px sans-serif';ctx.textAlign='left';ctx.fillStyle='#ffffff';ctx.fillText('✦ '+map.name,32,98);
    }
  }
  function loop(ts){if(!game||game.ended)return;const dt=game.lastTs?Math.min((ts-game.lastTs)/1000,.04):0;game.lastTs=ts;update(dt);if(game&&!game.ended){draw();updateHud();raf=requestAnimationFrame(loop);}}
  function unlock(i,out){
    if(!Number.isInteger(i)||i<0||i>=FIGHTERS.length||save.owned.includes(i))return;
    if(i===FINAL_FIGHTER_ID&&!allBaseOwned())return;
    save.owned.push(i);out.push(i);
    if(i!==FINAL_FIGHTER_ID&&allBaseOwned()&&!save.owned.includes(FINAL_FIGHTER_ID)){
      save.owned.push(FINAL_FIGHTER_ID);out.push(FINAL_FIGHTER_ID);
    }
  }
  function grantVictory(){const gained=[],ticketsAwarded=[];save.wins++;save.totalXp+=200;save.coins+=400;save.matches++;save.kos+=game.actors[0].kills;
    const fighterId=game.fighterId,previousLevel=fighterLevel(fighterId);
    save.fighterWins[fighterId]=fighterWinCount(fighterId)+1;
    const nextLevel=fighterLevel(fighterId),levelUp=nextLevel>previousLevel?nextLevel:null;
    const i=save.target;if(Number.isInteger(i)&&i>0&&i<FINAL_FIGHTER_ID&&!save.owned.includes(i)){
      save.invested[i]=Math.max(0,Number(save.invested[i]||0))+200;
      if(save.invested[i]>=xpCost(i))unlock(i,gained);
    }
    for(let id=1;id<FINAL_FIGHTER_ID;id++){if(save.wins>=ladderThreshold(id))unlock(id,gained);else break;}
    for(const t of TICKET_TYPES){if(save.wins%t.every===0){save.tickets[t.id]++;ticketsAwarded.push(t);}}
    if(save.owned.includes(save.target)){const n=nextUnowned();if(n!==null)save.target=n;}
    persist();return {gained,ticketsAwarded,levelUp};
  }
  function finishGame(won,timed){if(!game||game.ended)return;game.ended=true;cancelAnimationFrame(raf);for(const k in held)updateHeld(k,false);
    const kills=game.actors[0].kills;const rewards=game.trial?{gained:[],ticketsAwarded:[]}:won?grantVictory():(save.matches++,save.kos+=kills,save.totalXp+=100,save.coins+=200,(()=>{const i=save.target,gained=[];if(Number.isInteger(i)&&i>0&&i<FINAL_FIGHTER_ID&&!save.owned.includes(i)){save.invested[i]=Math.max(0,Number(save.invested[i]||0))+100;if(save.invested[i]>=xpCost(i))unlock(i,gained);if(save.owned.includes(save.target)){const n=nextUnowned();if(n!==null)save.target=n;}}persist();return {gained,ticketsAwarded:[]};})());
    $('resultIcon').textContent=won?'🏆':'💥';$('resultSubtitle').textContent=won?'VICTORY!':'TRY AGAIN';$('resultTitle').textContent=won?'승리!':'아쉽다!';
    $('resultDescription').textContent=(won?`${game.mode==='duo'?'우리 팀이':'네가'} 아레나에서 이겼어! ${kills}명 처치했어.${timed?' 제한 시간이 끝나 판정승!':''}`:`이번엔 패배했어. ${kills}명 처치했어. 다시 도전해 보자!`)+(game.trial?' (체험전이라 기록은 저장되지 않아.)':'');
    $('resultRewards').innerHTML=`<div class="reward-box">${won&&!game.trial?'⚡ +200 XP · 🪙 +400코인':game.trial?'⚡ +0 XP · 🪙 +0코인':'⚡ +100 XP · 🪙 +200코인'}<small>${game.trial?'체험전: XP·승수·뽑기권·전적 보상 없음':won?'선택한 캐릭터의 XP와 승리 계단에 반영됐어.':'패배 보상도 선택한 캐릭터의 XP에 반영됐어.'}</small></div>${rewards.levelUp?`<div class="level-up-banner">⭐ 레벨 UP! ${FIGHTERS[game.fighterId].name} Lv.${rewards.levelUp}${rewards.levelUp===5?' · ✨ 특수 공격 해금!':''}</div>`:''}${rewards.gained.map(i=>`<div class="unlock-banner">🎉 새 파이터 획득! ${FIGHTERS[i].icon} ${FIGHTERS[i].name}</div>`).join('')}${rewards.ticketsAwarded.map(t=>`<div class="ticket-banner">${t.icon} ${t.name} 1장 획득! · 도감 화면에서 뽑기 가능</div>`).join('')}`;
    $('resultOverlay').classList.remove('hidden');renderAll();
  }
  function leaveBattle(){if(game){game.ended=true;cancelAnimationFrame(raf);game=null;}for(const k in held)updateHeld(k,false);resetJoystick();$('battleScreen').classList.add('hidden');$('resultOverlay').classList.add('hidden');$('homeScreen').classList.remove('hidden');renderAll();}
  $('startBattle').onclick=()=>spawnGame();$('playAgain').onclick=()=>spawnGame(game?.fighterId??save.selected);$('backHome').onclick=leaveBattle;
  $('quitBattle').onclick=()=>{if(game?.practice){leaveBattle();return;}if(game&&!game.ended&&confirm('전투를 나갈까? 진행 중인 경기는 승리로 기록되지 않아.'))leaveBattle();else if(game?.ended)leaveBattle();};
  renderAll();
})();