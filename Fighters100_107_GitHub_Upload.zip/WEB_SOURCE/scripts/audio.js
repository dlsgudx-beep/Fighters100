/* Original synthesized effects; music credits are in AUDIO_CREDITS.txt. */
(() => {
'use strict';
const KEY='fighters107_audio_v1';
let prefs={music:.35,sfx:.55};
try {const s=JSON.parse(localStorage.getItem(KEY)); for(const k of ['music','sfx']) if(s&&Number.isFinite(s[k]))prefs[k]=Math.max(0,Math.min(1,s[k]));}catch{}
let context,master,compressor,scene='menu',active=true;
const tracks={menu:new Audio('audio/menu.mp3'),battle:new Audio('audio/battle.mp3')};
for(const a of Object.values(tracks)){a.loop=true;a.preload='auto';a.volume=prefs.music;}
function sync(){for(const [k,a] of Object.entries(tracks)){a.volume=prefs.music;if(active&&!document.hidden&&scene===k&&prefs.music>0)a.play().catch(()=>{});else a.pause();}}
function unlock(){if(!context){try{context=new (window.AudioContext||window.webkitAudioContext)();master=context.createGain();master.gain.value=prefs.sfx;compressor=context.createDynamicsCompressor();compressor.threshold.value=-18;compressor.ratio.value=8;master.connect(compressor);compressor.connect(context.destination);}catch{}}if(active&&context?.state==='suspended')context.resume().catch(()=>{});sync();}
function tone(f,to,t,d=.18,amp=.2,type='sine'){if(!context||!master||!active||document.hidden||prefs.sfx===0)return;const o=context.createOscillator(),g=context.createGain();o.type=type;o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(Math.max(30,to),t+d);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(amp,t+.008);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(master);o.start(t);o.stop(t+d+.02);o.onended=()=>{o.disconnect();g.disconnect();};}
function effect(kind){if(!context||context.state!=='running')return;const t=context.currentTime;
 switch(kind){
 case 'ball':tone(680,270,t,.13,.24);tone(920,510,t+.035,.1,.09);break;
 case 'beam':tone(1200,340,t,.23,.16,'triangle');tone(1500,600,t+.035,.19,.06);break;
 case 'radial':[523,659,784].forEach((f,i)=>tone(f,f*.75,t+i*.035,.21,.12));break;
 case 'wind':[430,660,880].forEach((f,i)=>tone(f,f*1.4,t+i*.04,.15,.10));break;
 case 'throw':tone(500,980,t,.12,.15);tone(950,450,t+.09,.13,.10);break;
 case 'bomb':tone(230,85,t,.23,.19);tone(750,370,t+.05,.15,.10);break;
 case 'slash':tone(950,360,t,.1,.15,'triangle');tone(520,720,t+.03,.08,.08);break;
 case 'victory':[523,659,784,1047].forEach((f,i)=>tone(f,f,t+i*.13,i===3?.55:.22,.20));break;
 case 'defeat':[659,587,440,392].forEach((f,i)=>tone(f,f*.98,t+i*.16,i===3?.45:.22,.16));break;
 }
}
function family(id){if(id===99)return 'ball';if(id===100||id===101||id===104)return 'radial';if(id===102)return 'bomb';if(id===103)return 'wind';if(id>=105)return 'beam';return ['slash','wind','throw','throw','radial','beam','radial','ball','bomb','beam'][((id%10)+10)%10];}
function setScene(next){const b=document.getElementById('audioSettingsButton');if(b)b.style.display=next==='menu'?'':'none';if(next!==scene){for(const a of Object.values(tracks)){a.pause();a.currentTime=0;}scene=next;}sync();}
function lifecycle(on){active=on;if(!on){Object.values(tracks).forEach(a=>a.pause());context?.suspend().catch(()=>{});}else unlock();}
window.GameAudio={attack:actor=>effect(family(actor.id)),family,effect,setScene,lifecycle,getSettings:()=>({...prefs}),getScene:()=>scene};
document.addEventListener('pointerdown',unlock,{passive:true});document.addEventListener('keydown',unlock);
document.addEventListener('visibilitychange',()=>lifecycle(!document.hidden));
const style=document.createElement('style');style.textContent=`#audioSettingsButton{position:fixed;right:12px;top:max(10px,env(safe-area-inset-top));z-index:70;border:1px solid #8ca7e0;border-radius:14px;background:#20365b;color:white;padding:10px 14px;font-weight:bold;cursor:pointer}#audioDialog{color:#edf4ff;background:#18283f;border:1px solid #8ca7e0;border-radius:22px;padding:24px;width:min(380px,88vw);max-height:85vh;overflow:auto}#audioDialog::backdrop{background:#040b19c9}#audioDialog h2{margin:0 0 20px}#audioDialog label{display:block;margin:18px 0 8px}#audioDialog input{width:100%;accent-color:#9cdcff;min-height:32px}#audioDialog button{padding:10px 15px;border-radius:12px;border:0;margin:10px 6px 0 0;background:#c1eaff;color:#14263d;font-weight:bold}#audioDialog small{display:block;line-height:1.7;color:#c3cfe2;margin-top:18px}#audioDialog a{color:#a6daff} .topbar{padding-right:112px!important}`;document.head.append(style);
const button=document.createElement('button');button.id='audioSettingsButton';button.textContent='⚙ 설정';button.setAttribute('aria-label','음악과 효과음 설정');document.body.append(button);
const dialog=document.createElement('dialog');dialog.id='audioDialog';dialog.innerHTML=`<h2>🎵 소리 설정</h2><label for="musicVolume">배경음악 <output id="musicPercent"></output></label><input id="musicVolume" type="range" min="0" max="100" step="1"><label for="sfxVolume">효과음 <output id="sfxPercent"></output></label><input id="sfxVolume" type="range" min="0" max="100" step="1"><p style="font-size:13px">0%는 음소거 · 설정은 자동 저장돼.</p><button id="audioPreview">✨ 효과음 듣기</button><button id="audioClose">닫기</button><small>음악: Kevin MacLeod (incompetech.com)<br>메인: Monkeys Spinning Monkeys<br>전투: Pixel Peeker Polka - faster<br>Licensed under Creative Commons: By Attribution 4.0<br><a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener">https://creativecommons.org/licenses/by/4.0/</a><br>음원은 용량을 줄여 변환했으며 반복 재생돼.<br>효과음: 이 게임용으로 직접 합성한 전자음</small>`;document.body.append(dialog);
for(const k of ['music','sfx']){const slider=document.getElementById(k+'Volume'),out=document.getElementById(k+'Percent');slider.value=Math.round(prefs[k]*100);out.value=slider.value+'%';slider.oninput=()=>{prefs[k]=Number(slider.value)/100;out.value=slider.value+'%';if(master)master.gain.setTargetAtTime(prefs.sfx,context.currentTime,.015);try{localStorage.setItem(KEY,JSON.stringify(prefs));}catch{}sync();};}
button.onclick=()=>dialog.showModal();document.getElementById('audioClose').onclick=()=>dialog.close();document.getElementById('audioPreview').onclick=()=>{unlock();effect('radial');};dialog.addEventListener('close',()=>button.focus());
sync();
})();
