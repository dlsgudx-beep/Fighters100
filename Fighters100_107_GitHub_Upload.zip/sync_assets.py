from pathlib import Path
import shutil
p=Path(__file__).resolve().parent
shutil.copytree(p/'WEB_SOURCE',p/'app/src/main/assets',dirs_exist_ok=True)
print('Web source copied to Android assets')
