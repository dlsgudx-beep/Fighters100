파이터즈 100 · 107명 · 음악/효과음 버전 1.4-107-audio

메인: Monkeys Spinning Monkeys / 전투: Pixel Peeker Polka - faster.
설정 버튼: 메인 화면 오른쪽 위. 음악과 효과음을 각각 0~100% 조절, 자동 저장.
플레이어/NPC 구분 없이 화면 안의 공격자에게 7계열 합성 효과음 적용.
승리·패배 멜로디, 훈련장 음악, 앱 비활성 시 오디오 일시정지.
곡과 출처 표기는 APK 안에 포함되며 게임은 오프라인 동작.

[편집 구조]
WEB_SOURCE는 편집 가능한 웹 소스. app/src/main/assets와 동일한 내용입니다.
수정 후 python3 sync_assets.py를 실행한 다음 빌드하세요.
ORIGINAL은 전달받은 음악 추가 전 원본 HTML로 보관한 것입니다.
게임 진행 저장 키 fighters100_arena_save_v1은 그대로 유지했습니다.
오디오 설정은 별도 키 fighters107_audio_v1을 사용합니다.

[Android Studio / GitHub Actions]
Android Studio에서 이 폴더를 열어 Gradle 동기화 후 APK 빌드.
또는 전체 내용을 GitHub 저장소 루트에 올리고 Actions의 Build Fighters100 107 APK 실행.
app/build/outputs/apk/debug/app-debug.apk가 결과물입니다.
Gradle 8.10.2, JDK 17, Android SDK 35가 필요합니다.
Gradle 없이도 JDK와 Android SDK가 있으면 build_local.sh를 사용할 수 있습니다.

[설치와 저장]
이번 APK는 signing/local-game.jks로 서명했습니다. 향후 빌드도 같은 키를 사용하세요.
개인 테스트용 키이며 비밀번호는 android입니다. 공개 배포용 비밀 키가 아닙니다.
기존 APK의 서명키는 제공되지 않아 기존 앱 위 업데이트 설치는 확인하지 못했습니다.
설치 충돌이 나면 기존 앱을 바로 삭제하지 마세요. 삭제 시 게임 기록이 사라질 수 있습니다.
웹사이트 저장 기록은 APK에 자동 이전되지 않습니다.

[검증]
APK 빌드 완료, Android v2/v3 서명 검증 통과, MP3 전체 디코딩 오류 없음.
DOM 모의 환경에서 107캐릭터 × 플레이어/NPC 2종 = 214개 공격 호출을 확인했습니다.
음악 전환, 승리/패배, 훈련, 설정 저장, 비활성 정지, 음소거 검사 통과.
이 환경의 브라우저는 socket 권한 오류로 실행하지 못했습니다.
실제 Android 기기 설치, 화면 렌더링, 스피커 재생은 확인하지 못했습니다.
검사 상세는 validation/test-report.json을 참고하세요.
음원 저작자/라이선스는 AUDIO_CREDITS.txt와 게임 설정에 있습니다.

[1.5 수정]
상하좌우 실선 경계 및 캐릭터 외곽을 포함한 이동 제한.
캔버스가 화면 높이보다 커져 하단이 잘리지 않도록 크기 계산 레이아웃 수정.
내 캐릭터가 사망한 결과는 쓰러진 표시를 1초 보여준 뒤 표시.
더블 모드는 팀원의 생존 여부에 따른 기존 종료 규칙 유지.

[1.6 모바일 수정]
Android Activity를 sensorLandscape로 설정하여 가로 방향 고정(좌/우 회전 허용).
가로 스마트폰에서 전투 HUD/조작 버튼 크기 조정, 안전 영역 반영.
승리/패배 창 높이 제한 및 보상 스크롤, 짧은 화면에서 가로 버튼 배치.
전투/연습 중 나가기 클릭 시 실제 게임 루프를 정지하는 확인 팝업 표시.
계속하기는 시간 점프 없이 재개, 나가기는 메인으로 이동.
DOM 검사에서 정지 중 시간/프레임/체력 불변, 재개/나가기 확인.
실제 Android 기기 화면 및 회전 동작은 아직 확인하지 못했습니다.
