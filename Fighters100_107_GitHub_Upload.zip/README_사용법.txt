파이터즈 100 (107명) — APK 제작을 위한 전체 원본자료

이 압축파일은 사용자가 이번 대화에 직접 올린
Fighters100_107_Complete_Play.html 을 기준으로 만들었습니다.
실제 APK 파일은 아닙니다. Android Studio/GitHub Actions에서 APK를 빌드할 수 있는 소스 프로젝트입니다.

[폴더]
ORIGINAL/Fighters100_107_Complete_Play.html
    보상 수치만 수정한 단일 HTML 게임 소스.
app/src/main/assets/index.html
    안드로이드 WebView에서 열리는 파일. ORIGINAL 파일과 동일한 수정본.
WEB_SOURCE/index.html, styles/*.css, scripts/*.js
    편집하기 쉽게 웹 파일을 분리한 별도 소스. APK에는 별도 소스가 아닌 원본 HTML을 사용함.
app/src/main/java/com/fighters100/arena/GameActivity.java
    WebView로 오프라인 HTML을 표시하는 앱 진입 코드.
app/src/main/AndroidManifest.xml
    앱 설정.
app/build.gradle, build.gradle, settings.gradle, gradle.properties
    안드로이드 빌드 설정.
.github/workflows/build-apk.yml
    GitHub Actions APK 자동 빌드 설정.

[APK 만들기 — GitHub Actions]
1. 압축을 해제합니다.
2. 폴더 안의 모든 내용을 GitHub 저장소 최상위에 업로드합니다.
   (.github 폴더가 반드시 업로드돼야 합니다.)
3. 저장소 Actions 탭에서 'Build Fighters100 107 APK' 실행.
4. 작업이 성공하면 Artifacts 항목의 Fighters100_107_Debug_APK를 내려받습니다.
5. 내려받은 ZIP 안에 app-debug.apk 가 있습니다.

[APK 만들기 — Android Studio]
1. 압축을 해제한 폴더를 Android Studio로 엽니다.
2. Gradle 동기화를 완료합니다(인터넷 연결 필요).
3. Build > Build APK(s) 를 실행합니다.
4. app/build/outputs/apk/debug/app-debug.apk 파일을 사용합니다.

[저장에 관한 주의사항]
이 소스의 게임은 localStorage의 'fighters100_arena_save_v1' 키로 저장합니다.
APK에는 오프라인 웹뷰의 전용 저장 공간이 생깁니다.
기존 브라우저/웹사이트에서 모은 코인, XP, 캐릭터는 APK로 자동 이전되지 않습니다.
Android 앱에서도 설치를 삭제하거나 데이터를 지우면 진행 상황이 사라질 수 있습니다.
기존 앱과 같은 패키지명이라도 APK 서명키가 다르면 덮어쓰기 설치가 안 될 수 있습니다.
기존 기록을 보존하고 싶다면 데이터를 지우거나 이전 앱을 삭제하기 전에 확인하세요.

[검증 범위]
HTML 두 사본 일치 여부 및 JS 문법 검사를 수행합니다.
Android SDK/Gradle 빌드 도구가 이 작업환경에 없어서 실제 APK 빌드/설치 검사는 못 했습니다.
또한 이것은 사용자가 올린 107번 HTML 버전이며, 과거 원래 온라인 사이트와 동일하다는 주장은 하지 않습니다.

[보상 변경]
일반 대전 승리: XP 200 / 코인 400
일반 대전 패배: XP 100 / 코인 200
체험전: 보상 없음(기존 유지)
기존 보유 코인/XP에는 소급 지급하지 않습니다.
