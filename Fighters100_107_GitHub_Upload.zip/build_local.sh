#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
BT="$ANDROID_HOME/build-tools/35.0.0"
AJ="$ANDROID_HOME/platforms/android-35/android.jar"
python3 sync_assets.py
mkdir -p local-build/classes
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/AndroidManifest.xml').read_text().replace('<manifest ', '<manifest package="com.fighters100.arena" android:versionCode="7" android:versionName="1.6-107-mobile" ').replace('    <application','    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="35" />\n    <application')
Path('local-build/AndroidManifest.xml').write_text(s)
PY
"$BT/aapt" package -f -M local-build/AndroidManifest.xml -I "$AJ" -A app/src/main/assets -F local-build/unsigned.apk
javac -source 8 -target 8 -classpath "$AJ" -d local-build/classes app/src/main/java/com/fighters100/arena/GameActivity.java
"$BT/d8" --lib "$AJ" --min-api 24 --output local-build local-build/classes/com/fighters100/arena/*.class
(cd local-build && zip -q unsigned.apk classes.dex)
"$BT/zipalign" -f -p 4 local-build/unsigned.apk local-build/aligned.apk
"$BT/apksigner" sign --ks signing/local-game.jks --ks-key-alias localgame --ks-pass pass:android --key-pass pass:android --out local-build/Fighters100_107_Audio.apk local-build/aligned.apk
"$BT/apksigner" verify --verbose local-build/Fighters100_107_Audio.apk
